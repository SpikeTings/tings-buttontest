/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(1);


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _react = _interopRequireDefault(__webpack_require__(2));

var _channels = __webpack_require__(3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Courtesy of https://feathericons.com/
const Icon = () => _react.default.createElement("i", {
  className: "icon fa fa-plug"
});

class tingsButtonTest {
  initialize(registry, store) {
    registry.registerChannelHeaderButtonAction( // icon - JSX element to use as the button's icon
    _react.default.createElement(Icon, null), // action - a function called when the button is clicked, passed the channel and channel member as arguments
    // null,
    () => {
      alert("tings Button Test!");
    }, // dropdown_text - string or JSX element shown for the dropdown button description
    "tings Button Test", "tings Button Test", () => {
      const state = store.getState();
      const channel = (0, _channels.getCurrentChannel)(state);
      return channel.name != 'tings';
    }, () => {
      const state = store.getState();
      const channel = (0, _channels.getCurrentChannel)(state);
      return channel.name != 'off-topic';
    });
  }

}

window.registerPlugin('com.spikeassociates.tings-buttontest', new tingsButtonTest());

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = React;

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect_1 = __webpack_require__(5);
var constants_1 = __webpack_require__(6);
var common_1 = __webpack_require__(22);
exports.getCurrentChannelId = common_1.getCurrentChannelId;
exports.getMyChannelMemberships = common_1.getMyChannelMemberships;
exports.getMyCurrentChannelMembership = common_1.getMyCurrentChannelMembership;
var general_1 = __webpack_require__(23);
var preferences_1 = __webpack_require__(26);
var posts_1 = __webpack_require__(33);
var teams_1 = __webpack_require__(27);
var roles_1 = __webpack_require__(35);
var users_1 = __webpack_require__(36);
var channel_utils_1 = __webpack_require__(37);
var helpers_1 = __webpack_require__(24);
var users_2 = __webpack_require__(36);
function getAllChannels(state) {
    return state.entities.channels.channels;
}
exports.getAllChannels = getAllChannels;
function getAllChannelStats(state) {
    return state.entities.channels.stats;
}
exports.getAllChannelStats = getAllChannelStats;
function getChannelsInTeam(state) {
    return state.entities.channels.channelsInTeam;
}
exports.getChannelsInTeam = getChannelsInTeam;
exports.getDirectChannelsSet = reselect_1.createSelector(getChannelsInTeam, function (channelsInTeam) {
    return channelsInTeam && new Set(channelsInTeam['']) || new Set();
});
function getChannelMembersInChannels(state) {
    return state.entities.channels.membersInChannel;
}
exports.getChannelMembersInChannels = getChannelMembersInChannels;
function sortChannelsByRecencyOrAlpha(locale, lastPosts, sorting, a, b) {
    if (sorting === 'recent') {
        return channel_utils_1.sortChannelsByRecency(lastPosts, a, b);
    }
    return channel_utils_1.sortChannelsByDisplayName(locale, a, b);
}
// mapAndSortChannelIds sorts channels, primarily by:
//   For all sections except unreads:
//     a. All other unread channels
//     b. Muted channels
//   For unreads section:
//     a. Non-muted channels with mentions
//     b. Muted channels with mentions
//     c. Remaining unread channels
//   And then secondary by alphabetical ("alpha") or chronological ("recency") order
exports.mapAndSortChannelIds = function (channels, currentUser, myMembers, lastPosts, sorting, sortMentionsFirst) {
    if (sortMentionsFirst === void 0) { sortMentionsFirst = false; }
    var locale = currentUser.locale || constants_1.General.DEFAULT_LOCALE;
    var mutedChannelIds = channels.
        filter(function (channel) { return channel_utils_1.isChannelMuted(myMembers[channel.id]); }).
        sort(sortChannelsByRecencyOrAlpha.bind(null, locale, lastPosts, sorting)).
        map(function (channel) { return channel.id; });
    var hasMentionedChannelIds = [];
    if (sortMentionsFirst) {
        hasMentionedChannelIds = channels.
            filter(function (channel) {
            var member = myMembers[channel.id];
            return member && member.mention_count > 0 && !channel_utils_1.isChannelMuted(member);
        }).
            sort(sortChannelsByRecencyOrAlpha.bind(null, locale, lastPosts, sorting)).
            map(function (channel) { return channel.id; });
    }
    var otherChannelIds = channels.
        filter(function (channel) {
        return !mutedChannelIds.includes(channel.id) && !hasMentionedChannelIds.includes(channel.id);
    }).
        sort(sortChannelsByRecencyOrAlpha.bind(null, locale, lastPosts, sorting)).
        map(function (channel) { return channel.id; });
    return sortMentionsFirst ? hasMentionedChannelIds.concat(mutedChannelIds, otherChannelIds) : otherChannelIds.concat(mutedChannelIds);
};
function filterChannels(unreadIds, favoriteIds, channelIds, unreadsAtTop, favoritesAtTop) {
    var channels = channelIds;
    if (unreadsAtTop) {
        channels = channels.filter(function (id) {
            return !unreadIds.includes(id);
        });
    }
    if (favoritesAtTop) {
        channels = channels.filter(function (id) {
            return !favoriteIds.includes(id);
        });
    }
    return channels;
}
exports.filterChannels = filterChannels;
function makeGetChannel() {
    return reselect_1.createSelector(getAllChannels, function (state, props) { return props.id; }, function (state) { return state.entities.users; }, preferences_1.getTeammateNameDisplaySetting, function (allChannels, channelId, users, teammateNameDisplay) {
        var channel = allChannels[channelId];
        if (channel) {
            return channel_utils_1.completeDirectChannelInfo(users, teammateNameDisplay, channel);
        }
        return channel;
    });
}
exports.makeGetChannel = makeGetChannel;
exports.getChannel = reselect_1.createSelector(getAllChannels, function (state, id) { return id; }, function (state) { return state.entities.users; }, preferences_1.getTeammateNameDisplaySetting, function (allChannels, channelId, users, teammateNameDisplay) {
    var channel = allChannels[channelId];
    if (channel) {
        return channel_utils_1.completeDirectChannelInfo(users, teammateNameDisplay, channel);
    }
    return channel;
});
exports.getCurrentChannel = reselect_1.createSelector(getAllChannels, common_1.getCurrentChannelId, function (state) { return state.entities.users; }, preferences_1.getTeammateNameDisplaySetting, function (allChannels, currentChannelId, users, teammateNameDisplay) {
    var channel = allChannels[currentChannelId];
    if (channel) {
        return channel_utils_1.completeDirectChannelInfo(users, teammateNameDisplay, channel);
    }
    return channel;
});
exports.getMyChannelMember = reselect_1.createSelector(common_1.getMyChannelMemberships, function (state, channelId) { return channelId; }, function (channelMemberships, channelId) {
    return channelMemberships[channelId] || null;
});
exports.getCurrentChannelStats = reselect_1.createSelector(getAllChannelStats, common_1.getCurrentChannelId, function (allChannelStats, currentChannelId) {
    return allChannelStats[currentChannelId];
});
exports.isCurrentChannelFavorite = reselect_1.createSelector(preferences_1.getMyPreferences, common_1.getCurrentChannelId, function (preferences, channelId) { return channel_utils_1.isFavoriteChannel(preferences, channelId); });
exports.isCurrentChannelMuted = reselect_1.createSelector(common_1.getMyCurrentChannelMembership, function (membership) {
    if (!membership) {
        return false;
    }
    return channel_utils_1.isChannelMuted(membership);
});
exports.isCurrentChannelArchived = reselect_1.createSelector(exports.getCurrentChannel, function (channel) { return channel.delete_at !== 0; });
exports.isCurrentChannelDefault = reselect_1.createSelector(exports.getCurrentChannel, function (channel) { return channel_utils_1.isDefault(channel); });
function isCurrentChannelReadOnly(state) {
    return isChannelReadOnly(state, exports.getCurrentChannel(state));
}
exports.isCurrentChannelReadOnly = isCurrentChannelReadOnly;
function isChannelReadOnlyById(state, channelId) {
    return isChannelReadOnly(state, exports.getChannel(state, channelId));
}
exports.isChannelReadOnlyById = isChannelReadOnlyById;
function isChannelReadOnly(state, channel) {
    return channel && channel.name === constants_1.General.DEFAULT_CHANNEL && !users_1.isCurrentUserSystemAdmin(state) && general_1.getConfig(state).ExperimentalTownSquareIsReadOnly === 'true';
}
exports.isChannelReadOnly = isChannelReadOnly;
function shouldHideDefaultChannel(state, channel) {
    return channel && channel.name === constants_1.General.DEFAULT_CHANNEL && !users_1.isCurrentUserSystemAdmin(state) && general_1.getConfig(state).ExperimentalHideTownSquareinLHS === 'true';
}
exports.shouldHideDefaultChannel = shouldHideDefaultChannel;
function getChannelByName(state, channelName) {
    return channel_utils_1.getChannelByName(getAllChannels(state), channelName);
}
exports.getChannelByName = getChannelByName;
exports.getChannelSetInCurrentTeam = reselect_1.createSelector(teams_1.getCurrentTeamId, getChannelsInTeam, function (currentTeamId, channelsInTeam) {
    return channelsInTeam && channelsInTeam[currentTeamId] || [];
});
function sortAndInjectChannels(channels, channelSet, locale) {
    var currentChannels = [];
    if (typeof channelSet === 'undefined') {
        return currentChannels;
    }
    channelSet.forEach(function (c) {
        currentChannels.push(channels[c]);
    });
    return currentChannels.sort(channel_utils_1.sortChannelsByDisplayName.bind(null, locale));
}
exports.getChannelsInCurrentTeam = reselect_1.createSelector(getAllChannels, exports.getChannelSetInCurrentTeam, common_1.getCurrentUser, function (channels, currentTeamChannelSet, currentUser) {
    var locale = constants_1.General.DEFAULT_LOCALE;
    if (currentUser && currentUser.locale) {
        locale = currentUser.locale;
    }
    return sortAndInjectChannels(channels, currentTeamChannelSet, locale);
});
exports.getChannelsNameMapInTeam = reselect_1.createSelector(getAllChannels, getChannelsInTeam, function (state, teamId) { return teamId; }, function (channels, channelsInTeams, teamId) {
    var channelsInTeam = channelsInTeams[teamId] || [];
    var channelMap = {};
    channelsInTeam.forEach(function (id) {
        var channel = channels[id];
        channelMap[channel.name] = channel;
    });
    return channelMap;
});
exports.getChannelsNameMapInCurrentTeam = reselect_1.createSelector(getAllChannels, exports.getChannelSetInCurrentTeam, function (channels, currentTeamChannelSet) {
    var channelMap = {};
    currentTeamChannelSet.forEach(function (id) {
        var channel = channels[id];
        channelMap[channel.name] = channel;
    });
    return channelMap;
});
// Returns both DMs and GMs
exports.getAllDirectChannels = reselect_1.createSelector(getAllChannels, exports.getDirectChannelsSet, function (state) { return state.entities.users; }, preferences_1.getTeammateNameDisplaySetting, function (channels, channelSet, users, teammateNameDisplay) {
    var dmChannels = [];
    channelSet.forEach(function (c) {
        dmChannels.push(channel_utils_1.completeDirectChannelInfo(users, teammateNameDisplay, channels[c]));
    });
    return dmChannels;
});
// Returns only GMs
exports.getGroupChannels = reselect_1.createSelector(getAllChannels, exports.getDirectChannelsSet, function (state) { return state.entities.users; }, preferences_1.getTeammateNameDisplaySetting, function (channels, channelSet, users, teammateNameDisplay) {
    var gmChannels = [];
    channelSet.forEach(function (id) {
        var channel = channels[id];
        if (channel.type === constants_1.General.GM_CHANNEL) {
            gmChannels.push(channel_utils_1.completeDirectChannelInfo(users, teammateNameDisplay, channel));
        }
    });
    return gmChannels;
});
exports.getMyChannels = reselect_1.createSelector(exports.getChannelsInCurrentTeam, exports.getAllDirectChannels, common_1.getMyChannelMemberships, function (channels, directChannels, myMembers) {
    return tslib_1.__spread(channels, directChannels).filter(function (c) { return myMembers.hasOwnProperty(c.id); });
});
exports.getOtherChannels = reselect_1.createSelector(exports.getChannelsInCurrentTeam, common_1.getMyChannelMemberships, function (state, archived) {
    if (archived === void 0) { archived = true; }
    return archived;
}, function (channels, myMembers, archived) {
    return channels.filter(function (c) { return !myMembers.hasOwnProperty(c.id) && c.type === constants_1.General.OPEN_CHANNEL && (archived ? true : c.delete_at === 0); });
});
exports.getArchivedChannels = reselect_1.createSelector(exports.getChannelsInCurrentTeam, common_1.getMyChannelMemberships, function (channels, myMembers) {
    return channels.filter(function (c) { return myMembers.hasOwnProperty(c.id) && c.delete_at !== 0; });
});
exports.getChannelsByCategory = reselect_1.createSelector(common_1.getCurrentChannelId, exports.getMyChannels, common_1.getMyChannelMemberships, general_1.getConfig, preferences_1.getMyPreferences, preferences_1.getTeammateNameDisplaySetting, function (state) { return state.entities.users; }, posts_1.getLastPostPerChannel, function (currentChannelId, channels, myMembers, config, myPreferences, teammateNameDisplay, usersState, lastPosts) {
    var allChannels = channels.map(function (c) {
        var channel = tslib_1.__assign({}, c);
        channel.isCurrent = c.id === currentChannelId;
        return channel;
    });
    return channel_utils_1.buildDisplayableChannelList(usersState, allChannels, myMembers, config, myPreferences, teammateNameDisplay, lastPosts);
});
exports.getChannelsWithUnreadSection = reselect_1.createSelector(common_1.getCurrentChannelId, exports.getMyChannels, common_1.getMyChannelMemberships, general_1.getConfig, preferences_1.getMyPreferences, preferences_1.getTeammateNameDisplaySetting, function (state) { return state.entities.users; }, posts_1.getLastPostPerChannel, function (currentChannelId, channels, myMembers, config, myPreferences, teammateNameDisplay, usersState, lastPosts) {
    var allChannels = channels.map(function (c) {
        var channel = tslib_1.__assign({}, c);
        channel.isCurrent = c.id === currentChannelId;
        return channel;
    });
    return channel_utils_1.buildDisplayableChannelListWithUnreadSection(usersState, allChannels, myMembers, config, myPreferences, teammateNameDisplay, lastPosts);
});
exports.getDefaultChannel = reselect_1.createSelector(getAllChannels, teams_1.getCurrentTeamId, function (channels, teamId) {
    return Object.keys(channels).map(function (key) { return channels[key]; }).find(function (c) { return c && c.team_id === teamId && c.name === constants_1.General.DEFAULT_CHANNEL; });
});
exports.getMembersInCurrentChannel = reselect_1.createSelector(common_1.getCurrentChannelId, getChannelMembersInChannels, function (currentChannelId, members) {
    return members[currentChannelId];
});
exports.getUnreads = reselect_1.createSelector(getAllChannels, common_1.getMyChannelMemberships, common_1.getUsers, users_1.getCurrentUserId, teams_1.getCurrentTeamId, teams_1.getMyTeams, teams_1.getTeamMemberships, function (channels, myMembers, users, currentUserId, currentTeamId, myTeams, myTeamMemberships) {
    var messageCountForCurrentTeam = 0; // Includes message count from channels of current team plus all GM'S and all DM's across teams
    var mentionCountForCurrentTeam = 0; // Includes mention count from channels of current team plus all GM'S and all DM's across teams
    Object.keys(myMembers).forEach(function (channelId) {
        var channel = channels[channelId];
        var m = myMembers[channelId];
        if (!channel || !m) {
            return;
        }
        if (channel.team_id !== currentTeamId && channel.type !== constants_1.General.DM_CHANNEL && channel.type !== constants_1.General.GM_CHANNEL) {
            return;
        }
        var otherUserId = '';
        if (channel.type === constants_1.General.DM_CHANNEL) {
            otherUserId = channel_utils_1.getUserIdFromChannelName(currentUserId, channel.name);
            if (users[otherUserId] && users[otherUserId].delete_at === 0) {
                mentionCountForCurrentTeam += m.mention_count;
            }
        }
        else if (m.mention_count > 0 && channel.delete_at === 0) {
            mentionCountForCurrentTeam += m.mention_count;
        }
        if (m.notify_props && m.notify_props.mark_unread !== 'mention' && channel.total_msg_count - m.msg_count > 0) {
            if (channel.type === constants_1.General.DM_CHANNEL) {
                // otherUserId is guaranteed to have been set above
                if (users[otherUserId] && users[otherUserId].delete_at === 0) {
                    messageCountForCurrentTeam += 1;
                }
            }
            else if (channel.delete_at === 0) {
                messageCountForCurrentTeam += 1;
            }
        }
    });
    // Includes mention count and message count from teams other than the current team
    // This count does not include GM's and DM's
    var otherTeamsUnreadCountForChannels = myTeams.reduce(function (acc, team) {
        if (currentTeamId !== team.id) {
            var member = myTeamMemberships[team.id];
            acc.messageCount += member.msg_count;
            acc.mentionCount += member.mention_count;
        }
        return acc;
    }, {
        messageCount: 0,
        mentionCount: 0,
    });
    // messageCount is the number of unread channels, mention count is the total number of mentions
    return {
        messageCount: messageCountForCurrentTeam + otherTeamsUnreadCountForChannels.messageCount,
        mentionCount: mentionCountForCurrentTeam + otherTeamsUnreadCountForChannels.mentionCount,
    };
});
exports.getUnreadsInCurrentTeam = reselect_1.createSelector(common_1.getCurrentChannelId, exports.getMyChannels, common_1.getMyChannelMemberships, common_1.getUsers, users_1.getCurrentUserId, function (currentChannelId, channels, myMembers, users, currentUserId) {
    var messageCount = 0;
    var mentionCount = 0;
    channels.forEach(function (channel) {
        var m = myMembers[channel.id];
        if (m && channel.id !== currentChannelId) {
            var otherUserId = '';
            if (channel.type === 'D') {
                otherUserId = channel_utils_1.getUserIdFromChannelName(currentUserId, channel.name);
                if (users[otherUserId] && users[otherUserId].delete_at === 0) {
                    mentionCount += channel.total_msg_count - m.msg_count;
                }
            }
            else if (m.mention_count > 0 && channel.delete_at === 0) {
                mentionCount += m.mention_count;
            }
            if (m.notify_props && m.notify_props.mark_unread !== 'mention' && channel.total_msg_count - m.msg_count > 0) {
                if (channel.type === 'D') {
                    if (users[otherUserId] && users[otherUserId].delete_at === 0) {
                        messageCount += 1;
                    }
                }
                else if (channel.delete_at === 0) {
                    messageCount += 1;
                }
            }
        }
    });
    return {
        messageCount: messageCount,
        mentionCount: mentionCount,
    };
});
exports.canManageChannelMembers = reselect_1.createSelector(exports.getCurrentChannel, common_1.getCurrentUser, teams_1.getCurrentTeamMembership, common_1.getMyCurrentChannelMembership, general_1.getConfig, general_1.getLicense, general_1.hasNewPermissions, function (state) { return roles_1.haveICurrentChannelPermission(state, {
    permission: constants_1.Permissions.MANAGE_PRIVATE_CHANNEL_MEMBERS,
}); }, function (state) { return roles_1.haveICurrentChannelPermission(state, {
    permission: constants_1.Permissions.MANAGE_PUBLIC_CHANNEL_MEMBERS,
}); }, function (channel, user, teamMembership, channelMembership, config, license, newPermissions, managePrivateMembers, managePublicMembers) {
    if (!channel) {
        return false;
    }
    if (channel.delete_at !== 0) {
        return false;
    }
    if (channel.type === constants_1.General.DM_CHANNEL || channel.type === constants_1.General.GM_CHANNEL || channel.name === constants_1.General.DEFAULT_CHANNEL) {
        return false;
    }
    if (newPermissions) {
        if (channel.type === constants_1.General.OPEN_CHANNEL) {
            return managePublicMembers;
        }
        else if (channel.type === constants_1.General.PRIVATE_CHANNEL) {
            return managePrivateMembers;
        }
        return true;
    }
    if (!channelMembership) {
        return false;
    }
    return channel_utils_1.canManageMembersOldPermissions(channel, user, teamMembership, channelMembership, config, license);
}); // Determine if the user has permissions to manage members in at least one channel of the current team
exports.canManageAnyChannelMembersInCurrentTeam = reselect_1.createSelector(common_1.getMyChannelMemberships, teams_1.getCurrentTeamId, function (state) { return state; }, function (members, currentTeamId, state) {
    var e_1, _a;
    try {
        for (var _b = tslib_1.__values(Object.keys(members)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var channelId = _c.value;
            var channel = exports.getChannel(state, channelId);
            if (!channel || channel.team_id !== currentTeamId) {
                continue;
            }
            if (channel.type === constants_1.General.OPEN_CHANNEL && roles_1.haveIChannelPermission(state, {
                permission: constants_1.Permissions.MANAGE_PUBLIC_CHANNEL_MEMBERS,
                channel: channelId,
                team: currentTeamId,
            })) {
                return true;
            }
            else if (channel.type === constants_1.General.PRIVATE_CHANNEL && roles_1.haveIChannelPermission(state, {
                permission: constants_1.Permissions.MANAGE_PRIVATE_CHANNEL_MEMBERS,
                channel: channelId,
                team: currentTeamId,
            })) {
                return true;
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return false;
});
exports.getAllDirectChannelIds = helpers_1.createIdsSelector(exports.getDirectChannelsSet, function (directIds) {
    return Array.from(directIds);
});
exports.getChannelIdsInCurrentTeam = helpers_1.createIdsSelector(teams_1.getCurrentTeamId, getChannelsInTeam, function (currentTeamId, channelsInTeam) {
    return Array.from(channelsInTeam[currentTeamId] || []);
});
exports.getChannelIdsForCurrentTeam = helpers_1.createIdsSelector(exports.getChannelIdsInCurrentTeam, exports.getAllDirectChannelIds, function (channels, direct) {
    return tslib_1.__spread(channels, direct);
});
exports.getUnreadChannelIds = helpers_1.createIdsSelector(getAllChannels, common_1.getMyChannelMemberships, exports.getChannelIdsForCurrentTeam, function (state, lastUnreadChannel) {
    if (lastUnreadChannel === void 0) { lastUnreadChannel = null; }
    return lastUnreadChannel;
}, function (channels, members, teamChannelIds, lastUnreadChannel) {
    var unreadIds = teamChannelIds.filter(function (id) {
        var c = channels[id];
        var m = members[id];
        if (c && m) {
            var chHasUnread = c.total_msg_count - m.msg_count > 0;
            var chHasMention = m.mention_count > 0;
            if (m.notify_props && m.notify_props.mark_unread !== 'mention' && chHasUnread || chHasMention) {
                return true;
            }
        }
        return false;
    });
    if (lastUnreadChannel && !unreadIds.includes(lastUnreadChannel.id)) {
        unreadIds.push(lastUnreadChannel.id);
    }
    return unreadIds;
});
exports.getUnreadChannels = helpers_1.createIdsSelector(common_1.getCurrentUser, common_1.getUsers, users_2.getUserIdsInChannels, getAllChannels, exports.getUnreadChannelIds, preferences_1.getTeammateNameDisplaySetting, function (currentUser, profiles, userIdsInChannels, channels, unreadIds, settings) {
    // If we receive an unread for a channel and then a mention the channel
    // won't be sorted correctly until we receive a message in another channel
    if (!currentUser) {
        return [];
    }
    var allUnreadChannels = unreadIds.filter(function (id) { return channels[id] && channels[id].delete_at === 0; }).map(function (id) {
        var c = channels[id];
        if (c.type === constants_1.General.DM_CHANNEL || c.type === constants_1.General.GM_CHANNEL) {
            return channel_utils_1.completeDirectChannelDisplayName(currentUser.id, profiles, userIdsInChannels[id], settings, c);
        }
        return c;
    });
    return allUnreadChannels;
});
exports.getMapAndSortedUnreadChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannels, common_1.getCurrentUser, common_1.getMyChannelMemberships, posts_1.getLastPostPerChannel, function (state, lastUnreadChannel, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return sorting;
}, function (channels, currentUser, myMembers, lastPosts, sorting) {
    return exports.mapAndSortChannelIds(channels, currentUser, myMembers, lastPosts, sorting, true);
});
exports.getSortedUnreadChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return exports.getMapAndSortedUnreadChannelIds(state, lastUnreadChannel, sorting);
}, function (unreadChannelIds, mappedAndSortedUnreadChannelIds) { return mappedAndSortedUnreadChannelIds; }); // Favorites
exports.getFavoriteChannels = helpers_1.createIdsSelector(common_1.getCurrentUser, common_1.getUsers, users_2.getUserIdsInChannels, getAllChannels, common_1.getMyChannelMemberships, preferences_1.getFavoritesPreferences, exports.getChannelIdsForCurrentTeam, preferences_1.getTeammateNameDisplaySetting, general_1.getConfig, preferences_1.getMyPreferences, common_1.getCurrentChannelId, function (currentUser, profiles, userIdsInChannels, channels, myMembers, favoriteIds, teamChannelIds, settings, config, prefs, currentChannelId) {
    if (!currentUser) {
        return [];
    }
    var favoriteChannel = favoriteIds.filter(function (id) {
        if (!myMembers[id] || !channels[id]) {
            return false;
        }
        var channel = channels[id];
        var otherUserId = channel_utils_1.getUserIdFromChannelName(currentUser.id, channel.name);
        if (channel.delete_at !== 0 && channel.id !== currentChannelId) {
            return false;
        }
        // Deleted users from CLI will not have a profiles entry
        if (channel.type === constants_1.General.DM_CHANNEL && !profiles[otherUserId]) {
            return false;
        }
        if (channel.type === constants_1.General.DM_CHANNEL && !channel_utils_1.isDirectChannelVisible(profiles[otherUserId] || otherUserId, config, prefs, channel, null, false, currentChannelId)) {
            return false;
        }
        else if (channel.type === constants_1.General.GM_CHANNEL && !channel_utils_1.isGroupChannelVisible(config, prefs, channel)) {
            return false;
        }
        return teamChannelIds.includes(id);
    }).map(function (id) {
        var c = channels[id];
        if (c.type === constants_1.General.DM_CHANNEL || c.type === constants_1.General.GM_CHANNEL) {
            return channel_utils_1.completeDirectChannelDisplayName(currentUser.id, profiles, userIdsInChannels[id], settings, c);
        }
        return c;
    });
    return favoriteChannel;
});
exports.getFavoriteChannelIds = helpers_1.createIdsSelector(exports.getFavoriteChannels, common_1.getCurrentUser, common_1.getMyChannelMemberships, posts_1.getLastPostPerChannel, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return sorting;
}, exports.mapAndSortChannelIds);
exports.getSortedFavoriteChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) { return exports.getFavoriteChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting); }, function (state, lastUnreadChannel, unreadsAtTop) {
    if (unreadsAtTop === void 0) { unreadsAtTop = true; }
    return unreadsAtTop;
}, function (unreadChannelIds, favoritePreferences, favoriteChannelIds, unreadsAtTop) {
    return filterChannels(unreadChannelIds, favoritePreferences, favoriteChannelIds, unreadsAtTop, false);
});
// Public Channels
exports.getPublicChannels = reselect_1.createSelector(common_1.getCurrentUser, getAllChannels, common_1.getMyChannelMemberships, exports.getChannelIdsForCurrentTeam, function (currentUser, channels, myMembers, teamChannelIds) {
    if (!currentUser) {
        return [];
    }
    var publicChannels = teamChannelIds.filter(function (id) {
        if (!myMembers[id]) {
            return false;
        }
        var channel = channels[id];
        return teamChannelIds.includes(id) && channel.type === constants_1.General.OPEN_CHANNEL;
    }).map(function (id) { return channels[id]; });
    return publicChannels;
});
exports.getPublicChannelIds = helpers_1.createIdsSelector(exports.getPublicChannels, common_1.getCurrentUser, common_1.getMyChannelMemberships, posts_1.getLastPostPerChannel, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return sorting;
}, exports.mapAndSortChannelIds);
exports.getSortedPublicChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return exports.getPublicChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting);
}, function (state, lastUnreadChannel, unreadsAtTop) {
    if (unreadsAtTop === void 0) { unreadsAtTop = true; }
    return unreadsAtTop;
}, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, filterChannels); // Private Channels
exports.getPrivateChannels = reselect_1.createSelector(common_1.getCurrentUser, getAllChannels, common_1.getMyChannelMemberships, exports.getChannelIdsForCurrentTeam, function (currentUser, channels, myMembers, teamChannelIds) {
    if (!currentUser) {
        return [];
    }
    var privateChannels = teamChannelIds.filter(function (id) {
        if (!myMembers[id]) {
            return false;
        }
        var channel = channels[id];
        return teamChannelIds.includes(id) && channel.type === constants_1.General.PRIVATE_CHANNEL;
    }).map(function (id) { return channels[id]; });
    return privateChannels;
});
exports.getPrivateChannelIds = helpers_1.createIdsSelector(exports.getPrivateChannels, common_1.getCurrentUser, common_1.getMyChannelMemberships, posts_1.getLastPostPerChannel, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return sorting;
}, exports.mapAndSortChannelIds);
exports.getSortedPrivateChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return exports.getPrivateChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting);
}, function (state, lastUnreadChannel, unreadsAtTop) {
    if (unreadsAtTop === void 0) { unreadsAtTop = true; }
    return unreadsAtTop;
}, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, filterChannels); // Direct Messages
exports.getDirectChannels = reselect_1.createSelector(common_1.getCurrentUser, common_1.getUsers, users_2.getUserIdsInChannels, getAllChannels, preferences_1.getVisibleTeammate, preferences_1.getVisibleGroupIds, preferences_1.getTeammateNameDisplaySetting, general_1.getConfig, preferences_1.getMyPreferences, posts_1.getLastPostPerChannel, common_1.getCurrentChannelId, function (currentUser, profiles, userIdsInChannels, channels, teammates, groupIds, settings, config, preferences, lastPosts, currentChannelId) {
    if (!currentUser) {
        return [];
    }
    var channelValues = Object.keys(channels).map(function (key) { return channels[key]; });
    var directChannelsIds = [];
    teammates.reduce(function (result, teammateId) {
        var name = channel_utils_1.getDirectChannelName(currentUser.id, teammateId);
        var channel = channelValues.find(function (c) { return c && c.name === name; }); //eslint-disable-line max-nested-callbacks
        if (channel) {
            var lastPost = lastPosts[channel.id];
            var otherUser = profiles[channel_utils_1.getUserIdFromChannelName(currentUser.id, channel.name)];
            if (!channel_utils_1.isAutoClosed(config, preferences, channel, lastPost ? lastPost.create_at : 0, otherUser ? otherUser.delete_at : 0, currentChannelId)) {
                result.push(channel.id);
            }
        }
        return result;
    }, directChannelsIds);
    var directChannels = groupIds.filter(function (id) {
        var channel = channels[id];
        if (channel) {
            var lastPost = lastPosts[channel.id];
            return !channel_utils_1.isAutoClosed(config, preferences, channels[id], lastPost ? lastPost.create_at : 0, 0, currentChannelId);
        }
        return false;
    }).concat(directChannelsIds).map(function (id) {
        var channel = channels[id];
        return channel_utils_1.completeDirectChannelDisplayName(currentUser.id, profiles, userIdsInChannels[id], settings, channel);
    });
    return directChannels;
}); // getDirectAndGroupChannels returns all direct and group channels, even if they have been manually
// or automatically closed.
//
// This is similar to the getDirectChannels above (which actually also returns group channels,
// but suppresses manually closed group channels but not manually closed direct channels.) This
// method does away with all the suppression, since the webapp client downstream uses this for
// the channel switcher and puts such suppressed channels in a separate category.
exports.getDirectAndGroupChannels = reselect_1.createSelector(common_1.getCurrentUser, common_1.getUsers, users_2.getUserIdsInChannels, getAllChannels, preferences_1.getTeammateNameDisplaySetting, function (currentUser, profiles, userIdsInChannels, channels, settings) {
    if (!currentUser) {
        return [];
    }
    return Object.keys(channels).map(function (key) { return channels[key]; }).filter(function (channel) { return Boolean(channel); }).filter(function (channel) { return channel.type === constants_1.General.DM_CHANNEL || channel.type === constants_1.General.GM_CHANNEL; }).map(function (channel) { return channel_utils_1.completeDirectChannelDisplayName(currentUser.id, profiles, userIdsInChannels[channel.id], settings, channel); });
});
exports.getDirectChannelIds = helpers_1.createIdsSelector(exports.getDirectChannels, common_1.getCurrentUser, common_1.getMyChannelMemberships, posts_1.getLastPostPerChannel, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return sorting;
}, exports.mapAndSortChannelIds);
exports.getSortedDirectChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return exports.getDirectChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting);
}, function (state, lastUnreadChannel, unreadsAtTop) {
    if (unreadsAtTop === void 0) { unreadsAtTop = true; }
    return unreadsAtTop;
}, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, filterChannels);
function getGroupOrDirectChannelVisibility(state, channelId) {
    return channel_utils_1.isGroupOrDirectChannelVisible(exports.getChannel(state, channelId), common_1.getMyChannelMemberships(state), general_1.getConfig(state), preferences_1.getMyPreferences(state), common_1.getCurrentUser(state).id, common_1.getUsers(state), posts_1.getLastPostPerChannel(state));
}
exports.getGroupOrDirectChannelVisibility = getGroupOrDirectChannelVisibility;
// Filters post IDs by the given condition.
// The condition function receives as parameters the associated channel object and the post object.
exports.filterPostIds = function (condition) {
    if (typeof condition !== 'function') {
        throw new TypeError(condition + " is not a function");
    }
    return reselect_1.createSelector(getAllChannels, posts_1.getAllPosts, function (state, postIds) { return postIds; }, function (channels, posts, postIds) {
        return postIds.filter(function (postId) {
            var post = posts[postId];
            var channel;
            if (post) {
                channel = channels[post.channel_id];
            }
            return post && channel && condition(channel, post);
        });
    });
};
var getProfiles = function (currentUserId, usersIdsInChannel, users) {
    var profiles = [];
    usersIdsInChannel.forEach(function (userId) {
        if (userId !== currentUserId) {
            profiles.push(users[userId]);
        }
    });
    return profiles;
};
exports.getChannelsWithUserProfiles = reselect_1.createSelector(users_2.getUserIdsInChannels, common_1.getUsers, exports.getGroupChannels, users_1.getCurrentUserId, function (channelUserMap, users, channels, currentUserId) {
    return channels.map(function (channel) {
        var profiles = getProfiles(currentUserId, channelUserMap[channel.id] || [], users);
        return tslib_1.__assign(tslib_1.__assign({}, channel), { profiles: profiles });
    });
});
var getAllActiveChannels = reselect_1.createSelector(exports.getPublicChannels, exports.getPrivateChannels, exports.getDirectChannels, function (publicChannels, privateChannels, directChannels) {
    var allChannels = tslib_1.__spread(publicChannels, privateChannels, directChannels);
    return allChannels;
});
exports.getAllChannelIds = helpers_1.createIdsSelector(getAllActiveChannels, common_1.getCurrentUser, common_1.getMyChannelMemberships, posts_1.getLastPostPerChannel, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return sorting;
}, exports.mapAndSortChannelIds);
exports.getAllSortedChannelIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting) {
    if (sorting === void 0) { sorting = 'alpha'; }
    return exports.getAllChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting);
}, function (state, lastUnreadChannel, unreadsAtTop) {
    if (unreadsAtTop === void 0) { unreadsAtTop = true; }
    return unreadsAtTop;
}, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, filterChannels);
var lastChannels;
var hasChannelsChanged = function (channels) {
    if (!lastChannels || lastChannels.length !== channels.length) {
        return true;
    }
    for (var i = 0; i < channels.length; i++) {
        if (channels[i].type !== lastChannels[i].type || channels[i].items !== lastChannels[i].items) {
            return true;
        }
    }
    return false;
};
exports.getOrderedChannelIds = function (state, lastUnreadChannel, grouping, sorting, unreadsAtTop, favoritesAtTop) {
    var channels = [];
    if (grouping === 'by_type') {
        channels.push({
            type: 'public',
            name: 'PUBLIC CHANNELS',
            items: exports.getSortedPublicChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting),
        });
        channels.push({
            type: 'private',
            name: 'PRIVATE CHANNELS',
            items: exports.getSortedPrivateChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting),
        });
        channels.push({
            type: 'direct',
            name: 'DIRECT MESSAGES',
            items: exports.getSortedDirectChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting),
        });
    }
    else {
        // Combine all channel types
        var type = 'alpha';
        var name_1 = 'CHANNELS';
        if (sorting === 'recent') {
            type = 'recent';
            name_1 = 'RECENT ACTIVITY';
        }
        channels.push({
            type: type,
            name: name_1,
            items: exports.getAllSortedChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting),
        });
    }
    if (favoritesAtTop) {
        channels.unshift({
            type: 'favorite',
            name: 'FAVORITE CHANNELS',
            items: exports.getSortedFavoriteChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting),
        });
    }
    if (unreadsAtTop) {
        channels.unshift({
            type: 'unreads',
            name: 'UNREADS',
            items: exports.getSortedUnreadChannelIds(state, lastUnreadChannel, unreadsAtTop, favoritesAtTop, sorting),
        });
    }
    if (hasChannelsChanged(channels)) {
        lastChannels = channels;
    }
    return lastChannels;
};
// Added for backwards compatibility
// Can be removed once webapp includes new sidebar preferences
exports.getSortedPublicChannelWithUnreadsIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, exports.getPublicChannelIds, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, function (unreadChannelIds, favoritePreferences, publicChannelIds, favoritesAtTop) {
    return filterChannels(unreadChannelIds, favoritePreferences, publicChannelIds, false, favoritesAtTop);
});
exports.getSortedPrivateChannelWithUnreadsIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, exports.getPrivateChannelIds, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, function (unreadChannelIds, favoritePreferences, privateChannelId, favoritesAtTop) {
    return filterChannels(unreadChannelIds, favoritePreferences, privateChannelId, false, favoritesAtTop);
});
exports.getSortedFavoriteChannelWithUnreadsIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, exports.getFavoriteChannelIds, function (unreadChannelIds, favoriteChannelIds) { return favoriteChannelIds; });
exports.getSortedDirectChannelWithUnreadsIds = helpers_1.createIdsSelector(exports.getUnreadChannelIds, preferences_1.getFavoritesPreferences, exports.getDirectChannelIds, function (state, lastUnreadChannel, unreadsAtTop, favoritesAtTop) {
    if (favoritesAtTop === void 0) { favoritesAtTop = true; }
    return favoritesAtTop;
}, function (unreadChannelIds, favoritePreferences, directChannelIds, favoritesAtTop) {
    return filterChannels(unreadChannelIds, favoritePreferences, directChannelIds, false, favoritesAtTop);
});
exports.getDefaultChannelForTeams = reselect_1.createSelector(getAllChannels, function (channels) {
    var e_2, _a;
    var result = {};
    try {
        for (var _b = tslib_1.__values(Object.keys(channels).map(function (key) { return channels[key]; })), _c = _b.next(); !_c.done; _c = _b.next()) {
            var channel = _c.value;
            if (channel && channel.name === constants_1.General.DEFAULT_CHANNEL) {
                result[channel.team_id] = channel;
            }
        }
    }
    catch (e_2_1) { e_2 = { error: e_2_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_2) throw e_2.error; }
    }
    return result;
});
exports.getMyFirstChannelForTeams = reselect_1.createSelector(getAllChannels, common_1.getMyChannelMemberships, teams_1.getMyTeams, common_1.getCurrentUser, function (allChannels, myChannelMemberships, myTeams, currentUser) {
    var e_3, _a;
    var locale = currentUser.locale || constants_1.General.DEFAULT_LOCALE;
    var result = {};
    var _loop_1 = function (team) {
        // Get a sorted array of all channels in the team that the current user is a member of
        var teamChannels = Object.values(allChannels).filter(function (channel) { return channel && channel.team_id === team.id && Boolean(myChannelMemberships[channel.id]); }).sort(channel_utils_1.sortChannelsByDisplayName.bind(null, locale));
        if (teamChannels.length === 0) {
            return "continue";
        }
        result[team.id] = teamChannels[0];
    };
    try {
        for (var myTeams_1 = tslib_1.__values(myTeams), myTeams_1_1 = myTeams_1.next(); !myTeams_1_1.done; myTeams_1_1 = myTeams_1.next()) {
            var team = myTeams_1_1.value;
            _loop_1(team);
        }
    }
    catch (e_3_1) { e_3 = { error: e_3_1 }; }
    finally {
        try {
            if (myTeams_1_1 && !myTeams_1_1.done && (_a = myTeams_1.return)) _a.call(myTeams_1);
        }
        finally { if (e_3) throw e_3.error; }
    }
    return result;
});
exports.getRedirectChannelNameForTeam = function (state, teamId) {
    var defaultChannelForTeam = exports.getDefaultChannelForTeams(state)[teamId];
    var myFirstChannelForTeam = exports.getMyFirstChannelForTeams(state)[teamId];
    var canIJoinPublicChannelsInTeam = !general_1.hasNewPermissions(state) || roles_1.haveITeamPermission(state, {
        team: teamId,
        permission: constants_1.Permissions.JOIN_PUBLIC_CHANNELS,
    });
    var myChannelMemberships = common_1.getMyChannelMemberships(state);
    var iAmMemberOfTheTeamDefaultChannel = Boolean(defaultChannelForTeam && myChannelMemberships[defaultChannelForTeam.id]);
    if (iAmMemberOfTheTeamDefaultChannel || canIJoinPublicChannelsInTeam) {
        return constants_1.General.DEFAULT_CHANNEL;
    }
    return myFirstChannelForTeam && myFirstChannelForTeam.name || constants_1.General.DEFAULT_CHANNEL;
};
// isManually unread looks into state if the provided channelId is marked as unread by the user.
function isManuallyUnread(state, channelId) {
    if (!channelId) {
        return false;
    }
    return Boolean(state.entities.channels.manuallyUnread[channelId]);
}
exports.isManuallyUnread = isManuallyUnread;
//# sourceMappingURL=channels.js.map

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}


/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaultMemoize", function() { return defaultMemoize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSelectorCreator", function() { return createSelectorCreator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createSelector", function() { return createSelector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createStructuredSelector", function() { return createStructuredSelector; });
function defaultEqualityCheck(a, b) {
  return a === b;
}

function areArgumentsShallowlyEqual(equalityCheck, prev, next) {
  if (prev === null || next === null || prev.length !== next.length) {
    return false;
  }

  // Do this in a for loop (and not a `forEach` or an `every`) so we can determine equality as fast as possible.
  var length = prev.length;
  for (var i = 0; i < length; i++) {
    if (!equalityCheck(prev[i], next[i])) {
      return false;
    }
  }

  return true;
}

function defaultMemoize(func) {
  var equalityCheck = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultEqualityCheck;

  var lastArgs = null;
  var lastResult = null;
  // we reference arguments instead of spreading them for performance reasons
  return function () {
    if (!areArgumentsShallowlyEqual(equalityCheck, lastArgs, arguments)) {
      // apply arguments instead of spreading for performance.
      lastResult = func.apply(null, arguments);
    }

    lastArgs = arguments;
    return lastResult;
  };
}

function getDependencies(funcs) {
  var dependencies = Array.isArray(funcs[0]) ? funcs[0] : funcs;

  if (!dependencies.every(function (dep) {
    return typeof dep === 'function';
  })) {
    var dependencyTypes = dependencies.map(function (dep) {
      return typeof dep;
    }).join(', ');
    throw new Error('Selector creators expect all input-selectors to be functions, ' + ('instead received the following types: [' + dependencyTypes + ']'));
  }

  return dependencies;
}

function createSelectorCreator(memoize) {
  for (var _len = arguments.length, memoizeOptions = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    memoizeOptions[_key - 1] = arguments[_key];
  }

  return function () {
    for (var _len2 = arguments.length, funcs = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      funcs[_key2] = arguments[_key2];
    }

    var recomputations = 0;
    var resultFunc = funcs.pop();
    var dependencies = getDependencies(funcs);

    var memoizedResultFunc = memoize.apply(undefined, [function () {
      recomputations++;
      // apply arguments instead of spreading for performance.
      return resultFunc.apply(null, arguments);
    }].concat(memoizeOptions));

    // If a selector is called with the exact same arguments we don't need to traverse our dependencies again.
    var selector = memoize(function () {
      var params = [];
      var length = dependencies.length;

      for (var i = 0; i < length; i++) {
        // apply arguments instead of spreading and mutate a local list of params for performance.
        params.push(dependencies[i].apply(null, arguments));
      }

      // apply arguments instead of spreading for performance.
      return memoizedResultFunc.apply(null, params);
    });

    selector.resultFunc = resultFunc;
    selector.dependencies = dependencies;
    selector.recomputations = function () {
      return recomputations;
    };
    selector.resetRecomputations = function () {
      return recomputations = 0;
    };
    return selector;
  };
}

var createSelector = createSelectorCreator(defaultMemoize);

function createStructuredSelector(selectors) {
  var selectorCreator = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : createSelector;

  if (typeof selectors !== 'object') {
    throw new Error('createStructuredSelector expects first argument to be an object ' + ('where each property is a selector, instead received a ' + typeof selectors));
  }
  var objectKeys = Object.keys(selectors);
  return selectorCreator(objectKeys.map(function (key) {
    return selectors[key];
  }), function () {
    for (var _len3 = arguments.length, values = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      values[_key3] = arguments[_key3];
    }

    return values.reduce(function (composition, value, index) {
      composition[objectKeys[index]] = value;
      return composition;
    }, {});
  });
}

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var general_1 = tslib_1.__importDefault(__webpack_require__(7));
exports.General = general_1.default;
var request_status_1 = tslib_1.__importDefault(__webpack_require__(8));
exports.RequestStatus = request_status_1.default;
var websocket_1 = tslib_1.__importDefault(__webpack_require__(9));
exports.WebsocketEvents = websocket_1.default;
var preferences_1 = tslib_1.__importDefault(__webpack_require__(10));
exports.Preferences = preferences_1.default;
var posts_1 = tslib_1.__importDefault(__webpack_require__(11));
exports.Posts = posts_1.default;
var files_1 = tslib_1.__importDefault(__webpack_require__(12));
exports.Files = files_1.default;
var alerts_1 = tslib_1.__importDefault(__webpack_require__(13));
exports.Alerts = alerts_1.default;
var teams_1 = tslib_1.__importDefault(__webpack_require__(14));
exports.Teams = teams_1.default;
var stats_1 = tslib_1.__importDefault(__webpack_require__(15));
exports.Stats = stats_1.default;
var permissions_1 = tslib_1.__importDefault(__webpack_require__(17));
exports.Permissions = permissions_1.default;
var emoji_1 = tslib_1.__importDefault(__webpack_require__(18));
exports.Emoji = emoji_1.default;
var plugins_1 = tslib_1.__importDefault(__webpack_require__(19));
exports.Plugins = plugins_1.default;
var groups_1 = tslib_1.__importDefault(__webpack_require__(20));
exports.Groups = groups_1.default;
var users_1 = tslib_1.__importDefault(__webpack_require__(21));
exports.Users = users_1.default;
//# sourceMappingURL=index.js.map

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    CONFIG_CHANGED: 'config_changed',
    SERVER_VERSION_CHANGED: 'server_version_changed',
    PAGE_SIZE_DEFAULT: 60,
    PAGE_SIZE_MAXIMUM: 200,
    LOGS_PAGE_SIZE_DEFAULT: 10000,
    AUDITS_CHUNK_SIZE: 100,
    PROFILE_CHUNK_SIZE: 100,
    CHANNELS_CHUNK_SIZE: 50,
    TEAMS_CHUNK_SIZE: 50,
    JOBS_CHUNK_SIZE: 50,
    SEARCH_TIMEOUT_MILLISECONDS: 100,
    STATUS_INTERVAL: 60000,
    AUTOCOMPLETE_LIMIT_DEFAULT: 25,
    AUTOCOMPLETE_SPLIT_CHARACTERS: ['.', '-', '_'],
    MENTION: 'mention',
    OUT_OF_OFFICE: 'ooo',
    OFFLINE: 'offline',
    AWAY: 'away',
    ONLINE: 'online',
    DND: 'dnd',
    PERMISSIONS_ALL: 'all',
    PERMISSIONS_CHANNEL_ADMIN: 'channel_admin',
    PERMISSIONS_TEAM_ADMIN: 'team_admin',
    PERMISSIONS_SYSTEM_ADMIN: 'system_admin',
    TEAM_GUEST_ROLE: 'team_guest',
    TEAM_USER_ROLE: 'team_user',
    TEAM_ADMIN_ROLE: 'team_admin',
    CHANNEL_GUEST_ROLE: 'channel_guest',
    CHANNEL_USER_ROLE: 'channel_user',
    CHANNEL_ADMIN_ROLE: 'channel_admin',
    SYSTEM_GUEST_ROLE: 'system_guest',
    SYSTEM_USER_ROLE: 'system_user',
    SYSTEM_ADMIN_ROLE: 'system_admin',
    SYSTEM_USER_ACCESS_TOKEN_ROLE: 'system_user_access_token',
    SYSTEM_POST_ALL_ROLE: 'system_post_all',
    SYSTEM_POST_ALL_PUBLIC_ROLE: 'system_post_all_public',
    ALLOW_EDIT_POST_ALWAYS: 'always',
    ALLOW_EDIT_POST_NEVER: 'never',
    ALLOW_EDIT_POST_TIME_LIMIT: 'time_limit',
    DEFAULT_POST_EDIT_TIME_LIMIT: 300,
    RESTRICT_DIRECT_MESSAGE_ANY: 'any',
    RESTRICT_DIRECT_MESSAGE_TEAM: 'team',
    SWITCH_TO_DEFAULT_CHANNEL: 'switch_to_default_channel',
    DEFAULT_CHANNEL: 'town-square',
    DM_CHANNEL: 'D',
    OPEN_CHANNEL: 'O',
    PRIVATE_CHANNEL: 'P',
    GM_CHANNEL: 'G',
    PUSH_NOTIFY_APPLE_REACT_NATIVE: 'apple_rn',
    PUSH_NOTIFY_ANDROID_REACT_NATIVE: 'android_rn',
    STORE_REHYDRATION_COMPLETE: 'store_hydation_complete',
    OFFLINE_STORE_RESET: 'offline_store_reset',
    OFFLINE_STORE_PURGE: 'offline_store_purge',
    TEAMMATE_NAME_DISPLAY: {
        SHOW_USERNAME: 'username',
        SHOW_NICKNAME_FULLNAME: 'nickname_full_name',
        SHOW_FULLNAME: 'full_name',
    },
    SPECIAL_MENTIONS: ['all', 'channel', 'here'],
    MAX_USERS_IN_GM: 8,
    MIN_USERS_IN_GM: 3,
    MAX_GROUP_CHANNELS_FOR_PROFILES: 50,
    DEFAULT_LOCALE: 'en',
    DEFAULT_AUTOLINKED_URL_SCHEMES: ['http', 'https', 'ftp', 'mailto', 'tel'],
    DISABLED: 'disabled',
    DEFAULT_ON: 'default_on',
    DEFAULT_OFF: 'default_off',
};
//# sourceMappingURL=general.js.map

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var status = {
    NOT_STARTED: 'not_started',
    STARTED: 'started',
    SUCCESS: 'success',
    FAILURE: 'failure',
    CANCELLED: 'cancelled',
};
exports.default = status;
//# sourceMappingURL=request_status.js.map

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var WebsocketEvents = {
    POSTED: 'posted',
    POST_EDITED: 'post_edited',
    POST_DELETED: 'post_deleted',
    POST_UNREAD: 'post_unread',
    CHANNEL_CONVERTED: 'channel_converted',
    CHANNEL_CREATED: 'channel_created',
    CHANNEL_DELETED: 'channel_deleted',
    CHANNEL_UPDATED: 'channel_updated',
    CHANNEL_VIEWED: 'channel_viewed',
    CHANNEL_MEMBER_UPDATED: 'channel_member_updated',
    DIRECT_ADDED: 'direct_added',
    ADDED_TO_TEAM: 'added_to_team',
    LEAVE_TEAM: 'leave_team',
    UPDATE_TEAM: 'update_team',
    USER_ADDED: 'user_added',
    USER_REMOVED: 'user_removed',
    USER_UPDATED: 'user_updated',
    USER_ROLE_UPDATED: 'user_role_updated',
    ROLE_ADDED: 'role_added',
    ROLE_REMOVED: 'role_removed',
    ROLE_UPDATED: 'role_updated',
    TYPING: 'typing',
    STOP_TYPING: 'stop_typing',
    PREFERENCE_CHANGED: 'preference_changed',
    PREFERENCES_CHANGED: 'preferences_changed',
    PREFERENCES_DELETED: 'preferences_deleted',
    EPHEMERAL_MESSAGE: 'ephemeral_message',
    STATUS_CHANGED: 'status_change',
    HELLO: 'hello',
    WEBRTC: 'webrtc',
    REACTION_ADDED: 'reaction_added',
    REACTION_REMOVED: 'reaction_removed',
    EMOJI_ADDED: 'emoji_added',
    LICENSE_CHANGED: 'license_changed',
    CONFIG_CHANGED: 'config_changed',
    PLUGIN_STATUSES_CHANGED: 'plugin_statuses_changed',
    OPEN_DIALOG: 'open_dialog',
};
exports.default = WebsocketEvents;
//# sourceMappingURL=websocket.js.map

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
Object.defineProperty(exports, "__esModule", { value: true });
var Preferences = {
    CATEGORY_CHANNEL_OPEN_TIME: 'channel_open_time',
    CATEGORY_CHANNEL_APPROXIMATE_VIEW_TIME: 'channel_approximate_view_time',
    CATEGORY_DIRECT_CHANNEL_SHOW: 'direct_channel_show',
    CATEGORY_GROUP_CHANNEL_SHOW: 'group_channel_show',
    CATEGORY_FLAGGED_POST: 'flagged_post',
    CATEGORY_FAVORITE_CHANNEL: 'favorite_channel',
    CATEGORY_AUTO_RESET_MANUAL_STATUS: 'auto_reset_manual_status',
    CATEGORY_NOTIFICATIONS: 'notifications',
    COMMENTS: 'comments',
    COMMENTS_ANY: 'any',
    COMMENTS_ROOT: 'root',
    COMMENTS_NEVER: 'never',
    EMAIL: 'email',
    EMAIL_INTERVAL: 'email_interval',
    INTERVAL_FIFTEEN_MINUTES: 15 * 60,
    INTERVAL_HOUR: 60 * 60,
    INTERVAL_IMMEDIATE: 30,
    // "immediate" is a 30 second interval
    INTERVAL_NEVER: 0,
    INTERVAL_NOT_SET: -1,
    CATEGORY_DISPLAY_SETTINGS: 'display_settings',
    NAME_NAME_FORMAT: 'name_format',
    DISPLAY_PREFER_NICKNAME: 'nickname_full_name',
    DISPLAY_PREFER_FULL_NAME: 'full_name',
    DISPLAY_PREFER_USERNAME: 'username',
    MENTION_KEYS: 'mention_keys',
    USE_MILITARY_TIME: 'use_military_time',
    CATEGORY_SIDEBAR_SETTINGS: 'sidebar_settings',
    CATEGORY_ADVANCED_SETTINGS: 'advanced_settings',
    ADVANCED_FILTER_JOIN_LEAVE: 'join_leave',
    ADVANCED_CODE_BLOCK_ON_CTRL_ENTER: 'code_block_ctrl_enter',
    ADVANCED_SEND_ON_CTRL_ENTER: 'send_on_ctrl_enter',
    CATEGORY_THEME: 'theme',
    THEMES: {
        default: {
            type: 'Mattermost',
            sidebarBg: '#145dbf',
            sidebarText: '#ffffff',
            sidebarUnreadText: '#ffffff',
            sidebarTextHoverBg: '#4578bf',
            sidebarTextActiveBorder: '#579eff',
            sidebarTextActiveColor: '#ffffff',
            sidebarHeaderBg: '#1153ab',
            sidebarHeaderTextColor: '#ffffff',
            onlineIndicator: '#06d6a0',
            awayIndicator: '#ffbc42',
            dndIndicator: '#f74343',
            mentionBg: '#ffffff',
            mentionBj: '#ffffff',
            mentionColor: '#145dbf',
            centerChannelBg: '#ffffff',
            centerChannelColor: '#3d3c40',
            newMessageSeparator: '#ff8800',
            linkColor: '#2389d7',
            buttonBg: '#166de0',
            buttonColor: '#ffffff',
            errorTextColor: '#fd5960',
            mentionHighlightBg: '#ffe577',
            mentionHighlightLink: '#166de0',
            codeTheme: 'github',
        },
        organization: {
            type: 'Organization',
            sidebarBg: '#2071a7',
            sidebarText: '#ffffff',
            sidebarUnreadText: '#ffffff',
            sidebarTextHoverBg: '#136197',
            sidebarTextActiveBorder: '#7ab0d6',
            sidebarTextActiveColor: '#ffffff',
            sidebarHeaderBg: '#2f81b7',
            sidebarHeaderTextColor: '#ffffff',
            onlineIndicator: '#7dbe00',
            awayIndicator: '#dcbd4e',
            dndIndicator: '#ff6a6a',
            mentionBg: '#fbfbfb',
            mentionBj: '#fbfbfb',
            mentionColor: '#2071f7',
            centerChannelBg: '#f2f4f8',
            centerChannelColor: '#333333',
            newMessageSeparator: '#ff8800',
            linkColor: '#2f81b7',
            buttonBg: '#1dacfc',
            buttonColor: '#ffffff',
            errorTextColor: '#a94442',
            mentionHighlightBg: '#f3e197',
            mentionHighlightLink: '#2f81b7',
            codeTheme: 'github',
        },
        mattermostDark: {
            type: 'Mattermost Dark',
            sidebarBg: '#1b2c3e',
            sidebarText: '#ffffff',
            sidebarUnreadText: '#ffffff',
            sidebarTextHoverBg: '#4a5664',
            sidebarTextActiveBorder: '#66b9a7',
            sidebarTextActiveColor: '#ffffff',
            sidebarHeaderBg: '#1b2c3e',
            sidebarHeaderTextColor: '#ffffff',
            onlineIndicator: '#65dcc8',
            awayIndicator: '#c1b966',
            dndIndicator: '#e81023',
            mentionBg: '#b74a4a',
            mentionBj: '#b74a4a',
            mentionColor: '#ffffff',
            centerChannelBg: '#2f3e4e',
            centerChannelColor: '#dddddd',
            newMessageSeparator: '#5de5da',
            linkColor: '#a4ffeb',
            buttonBg: '#4cbba4',
            buttonColor: '#ffffff',
            errorTextColor: '#ff6461',
            mentionHighlightBg: '#984063',
            mentionHighlightLink: '#a4ffeb',
            codeTheme: 'solarized-dark',
        },
        windows10: {
            type: 'Windows Dark',
            sidebarBg: '#171717',
            sidebarText: '#ffffff',
            sidebarUnreadText: '#ffffff',
            sidebarTextHoverBg: '#302e30',
            sidebarTextActiveBorder: '#196caf',
            sidebarTextActiveColor: '#ffffff',
            sidebarHeaderBg: '#1f1f1f',
            sidebarHeaderTextColor: '#ffffff',
            onlineIndicator: '#399fff',
            awayIndicator: '#c1b966',
            dndIndicator: '#e81023',
            mentionBg: '#0177e7',
            mentionBj: '#0177e7',
            mentionColor: '#ffffff',
            centerChannelBg: '#1f1f1f',
            centerChannelColor: '#dddddd',
            newMessageSeparator: '#cc992d',
            linkColor: '#0d93ff',
            buttonBg: '#0177e7',
            buttonColor: '#ffffff',
            errorTextColor: '#ff6461',
            mentionHighlightBg: '#784098',
            mentionHighlightLink: '#a4ffeb',
            codeTheme: 'monokai',
        },
    },
};
exports.default = Preferences;
//# sourceMappingURL=preferences.js.map

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostTypes = {
    CHANNEL_DELETED: 'system_channel_deleted',
    DISPLAYNAME_CHANGE: 'system_displayname_change',
    CONVERT_CHANNEL: 'system_convert_channel',
    EPHEMERAL: 'system_ephemeral',
    EPHEMERAL_ADD_TO_CHANNEL: 'system_ephemeral_add_to_channel',
    HEADER_CHANGE: 'system_header_change',
    PURPOSE_CHANGE: 'system_purpose_change',
    JOIN_LEAVE: 'system_join_leave',
    JOIN_CHANNEL: 'system_join_channel',
    GUEST_JOIN_CHANNEL: 'system_guest_join_channel',
    LEAVE_CHANNEL: 'system_leave_channel',
    ADD_REMOVE: 'system_add_remove',
    ADD_TO_CHANNEL: 'system_add_to_channel',
    ADD_GUEST_TO_CHANNEL: 'system_add_guest_to_chan',
    REMOVE_FROM_CHANNEL: 'system_remove_from_channel',
    JOIN_TEAM: 'system_join_team',
    LEAVE_TEAM: 'system_leave_team',
    ADD_TO_TEAM: 'system_add_to_team',
    REMOVE_FROM_TEAM: 'system_remove_from_team',
    COMBINED_USER_ACTIVITY: 'system_combined_user_activity',
    ME: 'me',
    ADD_BOT_TEAMS_CHANNELS: 'add_bot_teams_channels',
};
exports.default = {
    POST_CHUNK_SIZE: 60,
    POST_DELETED: 'DELETED',
    SYSTEM_MESSAGE_PREFIX: 'system_',
    SYSTEM_AUTO_RESPONDER: 'system_auto_responder',
    POST_TYPES: exports.PostTypes,
    MESSAGE_TYPES: {
        POST: 'post',
        COMMENT: 'comment',
    },
    MAX_PREV_MSGS: 100,
    POST_COLLAPSE_TIMEOUT: 1000 * 60 * 5,
    IGNORE_POST_TYPES: [
        exports.PostTypes.ADD_REMOVE,
        exports.PostTypes.ADD_TO_CHANNEL,
        exports.PostTypes.CHANNEL_DELETED,
        exports.PostTypes.JOIN_LEAVE,
        exports.PostTypes.JOIN_CHANNEL,
        exports.PostTypes.LEAVE_CHANNEL,
        exports.PostTypes.REMOVE_FROM_CHANNEL,
        exports.PostTypes.JOIN_TEAM,
        exports.PostTypes.LEAVE_TEAM,
        exports.PostTypes.ADD_TO_TEAM,
        exports.PostTypes.REMOVE_FROM_TEAM,
    ],
    USER_ACTIVITY_POST_TYPES: [
        exports.PostTypes.ADD_TO_CHANNEL,
        exports.PostTypes.JOIN_CHANNEL,
        exports.PostTypes.LEAVE_CHANNEL,
        exports.PostTypes.REMOVE_FROM_CHANNEL,
        exports.PostTypes.ADD_TO_TEAM,
        exports.PostTypes.JOIN_TEAM,
        exports.PostTypes.LEAVE_TEAM,
        exports.PostTypes.REMOVE_FROM_TEAM,
    ],
};
//# sourceMappingURL=posts.js.map

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
Object.defineProperty(exports, "__esModule", { value: true });
var Files = {
    AUDIO_TYPES: ['mp3', 'wav', 'wma', 'm4a', 'flac', 'aac', 'ogg'],
    CODE_TYPES: ['as', 'applescript', 'osascript', 'scpt', 'bash', 'sh', 'zsh', 'clj', 'boot', 'cl2', 'cljc', 'cljs', 'cljs.hl', 'cljscm', 'cljx', 'hic', 'coffee', '_coffee', 'cake', 'cjsx', 'cson', 'iced', 'cpp', 'c', 'cc', 'h', 'c++', 'h++', 'hpp', 'cs', 'csharp', 'css', 'd', 'di', 'dart', 'delphi', 'dpr', 'dfm', 'pas', 'pascal', 'freepascal', 'lazarus', 'lpr', 'lfm', 'diff', 'django', 'jinja', 'dockerfile', 'docker', 'erl', 'f90', 'f95', 'fsharp', 'fs', 'gcode', 'nc', 'go', 'groovy', 'handlebars', 'hbs', 'html.hbs', 'html.handlebars', 'hs', 'hx', 'java', 'jsp', 'js', 'jsx', 'json', 'jl', 'kt', 'ktm', 'kts', 'less', 'lisp', 'lua', 'mk', 'mak', 'md', 'mkdown', 'mkd', 'matlab', 'm', 'mm', 'objc', 'obj-c', 'ml', 'perl', 'pl', 'php', 'php3', 'php4', 'php5', 'php6', 'ps', 'ps1', 'pp', 'py', 'gyp', 'r', 'ruby', 'rb', 'gemspec', 'podspec', 'thor', 'irb', 'rs', 'scala', 'scm', 'sld', 'scss', 'st', 'sql', 'swift', 'tex', 'vbnet', 'vb', 'bas', 'vbs', 'v', 'veo', 'xml', 'html', 'xhtml', 'rss', 'atom', 'xsl', 'plist', 'yaml'],
    IMAGE_TYPES: ['jpg', 'gif', 'bmp', 'png', 'jpeg', 'tiff', 'tif'],
    PATCH_TYPES: ['patch'],
    PDF_TYPES: ['pdf'],
    PRESENTATION_TYPES: ['ppt', 'pptx'],
    SPREADSHEET_TYPES: ['xlsx', 'csv'],
    TEXT_TYPES: ['txt', 'rtf'],
    VIDEO_TYPES: ['mp4', 'avi', 'webm', 'mkv', 'wmv', 'mpg', 'mov', 'flv'],
    WORD_TYPES: ['doc', 'docx'],
};
exports.default = Files;
//# sourceMappingURL=files.js.map

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var alerts = {
    ALERT_NOTIFICATION: 'notification',
    ALERT_DEVELOPER: 'developer',
    ALERT_ERROR: 'error',
};
exports.default = alerts;
//# sourceMappingURL=alerts.js.map

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    TEAM_TYPE_OPEN: 'O',
    TEAM_TYPE_INVITE: 'I',
};
//# sourceMappingURL=teams.js.map

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
var key_mirror_1 = tslib_1.__importDefault(__webpack_require__(16));
exports.default = key_mirror_1.default({
    TOTAL_USERS: null,
    TOTAL_INACTIVE_USERS: null,
    TOTAL_PUBLIC_CHANNELS: null,
    TOTAL_PRIVATE_GROUPS: null,
    TOTAL_POSTS: null,
    TOTAL_TEAMS: null,
    TOTAL_FILE_POSTS: null,
    TOTAL_HASHTAG_POSTS: null,
    TOTAL_IHOOKS: null,
    TOTAL_OHOOKS: null,
    TOTAL_COMMANDS: null,
    TOTAL_SESSIONS: null,
    POST_PER_DAY: null,
    BOT_POST_PER_DAY: null,
    USERS_WITH_POSTS_PER_DAY: null,
    RECENTLY_ACTIVE_USERS: null,
    NEWLY_CREATED_USERS: null,
    TOTAL_WEBSOCKET_CONNECTIONS: null,
    TOTAL_MASTER_DB_CONNECTIONS: null,
    TOTAL_READ_DB_CONNECTIONS: null,
    DAILY_ACTIVE_USERS: null,
    MONTHLY_ACTIVE_USERS: null,
});
//# sourceMappingURL=stats.js.map

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 */
/* eslint-disable header/header */
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Constructs an enumeration with keys equal to their value.
 *
 * For example:
 *
 *   var COLORS = keyMirror({blue: null, red: null});
 *   var myColor = COLORS.blue;
 *   var isColorValid = !!COLORS[myColor];
 *
 * The last line could not be performed if the values of the generated enum were
 * not equal to their keys.
 *
 *   Input:  {key1: val1, key2: val2}
 *   Output: {key1: key1, key2: key2}
 *
 * @param {object} obj
 * @return {object}
 */
function keyMirror(obj) {
    if (!(obj instanceof Object && !Array.isArray(obj))) {
        throw new Error('keyMirror(...): Argument must be an object.');
    }
    var ret = {};
    for (var key in obj) {
        if (!obj.hasOwnProperty(key)) {
            continue;
        }
        ret[key] = key;
    }
    return ret;
}
exports.default = keyMirror;
//# sourceMappingURL=key_mirror.js.map

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    INVITE_USER: 'invite_user',
    ADD_USER_TO_TEAM: 'add_user_to_team',
    USE_SLASH_COMMANDS: 'use_slash_commands',
    MANAGE_SLASH_COMMANDS: 'manage_slash_commands',
    MANAGE_OTHERS_SLASH_COMMANDS: 'manage_others_slash_commands',
    CREATE_PUBLIC_CHANNEL: 'create_public_channel',
    CREATE_PRIVATE_CHANNEL: 'create_private_channel',
    MANAGE_PUBLIC_CHANNEL_MEMBERS: 'manage_public_channel_members',
    MANAGE_PRIVATE_CHANNEL_MEMBERS: 'manage_private_channel_members',
    ASSIGN_SYSTEM_ADMIN_ROLE: 'assign_system_admin_role',
    MANAGE_ROLES: 'manage_roles',
    MANAGE_TEAM_ROLES: 'manage_team_roles',
    MANAGE_CHANNEL_ROLES: 'manage_channel_roles',
    MANAGE_SYSTEM: 'manage_system',
    CREATE_DIRECT_CHANNEL: 'create_direct_channel',
    CREATE_GROUP_CHANNEL: 'create_group_channel',
    MANAGE_PUBLIC_CHANNEL_PROPERTIES: 'manage_public_channel_properties',
    MANAGE_PRIVATE_CHANNEL_PROPERTIES: 'manage_private_channel_properties',
    LIST_PUBLIC_TEAMS: 'list_public_teams',
    JOIN_PUBLIC_TEAMS: 'join_public_teams',
    LIST_PRIVATE_TEAMS: 'list_private_teams',
    JOIN_PRIVATE_TEAMS: 'join_private_teams',
    LIST_TEAM_CHANNELS: 'list_team_channels',
    JOIN_PUBLIC_CHANNELS: 'join_public_channels',
    DELETE_PUBLIC_CHANNEL: 'delete_public_channel',
    DELETE_PRIVATE_CHANNEL: 'delete_private_channel',
    EDIT_OTHER_USERS: 'edit_other_users',
    READ_CHANNEL: 'read_channel',
    READ_PUBLIC_CHANNEL: 'read_public_channel',
    ADD_REACTION: 'add_reaction',
    REMOVE_REACTION: 'remove_reaction',
    REMOVE_OTHERS_REACTIONS: 'remove_others_reactions',
    PERMANENT_DELETE_USER: 'permanent_delete_user',
    UPLOAD_FILE: 'upload_file',
    GET_PUBLIC_LINK: 'get_public_link',
    MANAGE_WEBHOOKS: 'manage_webhooks',
    MANAGE_OTHERS_WEBHOOKS: 'manage_others_webhooks',
    MANAGE_INCOMING_WEBHOOKS: 'manage_incoming_webhooks',
    MANAGE_OTHERS_INCOMING_WEBHOOKS: 'manage_others_incoming_webhooks',
    MANAGE_OUTGOING_WEBHOOKS: 'manage_outgoing_webhooks',
    MANAGE_OTHERS_OUTGOING_WEBHOOKS: 'manage_others_outgoing_webhooks',
    MANAGE_OAUTH: 'manage_oauth',
    MANAGE_SYSTEM_WIDE_OAUTH: 'manage_system_wide_oauth',
    CREATE_POST: 'create_post',
    CREATE_POST_PUBLIC: 'create_post_public',
    EDIT_POST: 'edit_post',
    EDIT_OTHERS_POSTS: 'edit_others_posts',
    DELETE_POST: 'delete_post',
    DELETE_OTHERS_POSTS: 'delete_others_posts',
    REMOVE_USER_FROM_TEAM: 'remove_user_from_team',
    CREATE_TEAM: 'create_team',
    MANAGE_TEAM: 'manage_team',
    IMPORT_TEAM: 'import_team',
    VIEW_TEAM: 'view_team',
    LIST_USERS_WITHOUT_TEAM: 'list_users_without_team',
    CREATE_USER_ACCESS_TOKEN: 'create_user_access_token',
    READ_USER_ACCESS_TOKEN: 'read_user_access_token',
    REVOKE_USER_ACCESS_TOKEN: 'revoke_user_access_token',
    MANAGE_JOBS: 'manage_jobs',
    MANAGE_EMOJIS: 'manage_emojis',
    MANAGE_OTHERS_EMOJIS: 'manage_others_emojis',
    CREATE_EMOJIS: 'create_emojis',
    DELETE_EMOJIS: 'delete_emojis',
    DELETE_OTHERS_EMOJIS: 'delete_others_emojis',
    VIEW_MEMBERS: 'view_members',
    INVITE_GUEST: 'invite_guest',
    PROMOTE_GUEST: 'promote_guest',
    DEMOTE_TO_GUEST: 'demote_to_guest',
};
//# sourceMappingURL=permissions.js.map

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    SORT_BY_NAME: 'name',
};
//# sourceMappingURL=emoji.js.map

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    PLUGIN_STATE_NOT_RUNNING: 0,
    PLUGIN_STATE_STARTING: 1,
    PLUGIN_STATE_RUNNING: 2,
    PLUGIN_STATE_FAILED_TO_START: 3,
    PLUGIN_STATE_FAILED_TO_STAY_RUNNING: 4,
    PLUGIN_STATE_STOPPING: 5,
    PREPACKAGED_PLUGINS: ['zoom', 'jira', 'mattermost-autolink', 'com.mattermost.nps', 'com.mattermost.custom-attributes', 'github', 'com.mattermost.welcomebot', 'com.mattermost.aws-sns', 'com.github.manland.mattermost-plugin-gitlab', 'antivirus'],
};
//# sourceMappingURL=plugins.js.map

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    SYNCABLE_TYPE_TEAM: 'team',
    SYNCABLE_TYPE_CHANNEL: 'channel',
};
//# sourceMappingURL=groups.js.map

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
exports.default = {
    IGNORE_CHANNEL_MENTIONS_ON: 'on',
    IGNORE_CHANNEL_MENTIONS_OFF: 'off',
    IGNORE_CHANNEL_MENTIONS_DEFAULT: 'default',
};
//# sourceMappingURL=users.js.map

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var reselect_1 = __webpack_require__(5);
// Channels
function getCurrentChannelId(state) {
    return state.entities.channels.currentChannelId;
}
exports.getCurrentChannelId = getCurrentChannelId;
function getMyChannelMemberships(state) {
    return state.entities.channels.myMembers;
}
exports.getMyChannelMemberships = getMyChannelMemberships;
exports.getMyCurrentChannelMembership = reselect_1.createSelector(getCurrentChannelId, getMyChannelMemberships, function (currentChannelId, channelMemberships) {
    return channelMemberships[currentChannelId] || null;
});
// Users
function getCurrentUser(state) {
    return state.entities.users.profiles[getCurrentUserId(state)];
}
exports.getCurrentUser = getCurrentUser;
function getCurrentUserId(state) {
    return state.entities.users.currentUserId;
}
exports.getCurrentUserId = getCurrentUserId;
function getUsers(state) {
    return state.entities.users.profiles;
}
exports.getUsers = getUsers;
//# sourceMappingURL=common.js.map

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect_1 = __webpack_require__(5);
var helpers_1 = __webpack_require__(24);
var constants_1 = __webpack_require__(6);
function getConfig(state) {
    return state.entities.general.config;
}
exports.getConfig = getConfig;
function getLicense(state) {
    return state.entities.general.license;
}
exports.getLicense = getLicense;
function getSupportedTimezones(state) {
    return state.entities.general.timezones;
}
exports.getSupportedTimezones = getSupportedTimezones;
function getCurrentUrl(state) {
    return state.entities.general.credentials.url;
}
exports.getCurrentUrl = getCurrentUrl;
function isCompatibleWithJoinViewTeamPermissions(state) {
    var version = state.entities.general.serverVersion;
    return helpers_1.isMinimumServerVersion(version, 5, 10, 0) ||
        (version.indexOf('dev') !== -1 && helpers_1.isMinimumServerVersion(version, 5, 8, 0)) ||
        (version.match(/^5.8.\d.\d\d\d\d.*$/) !== null && helpers_1.isMinimumServerVersion(version, 5, 8, 0));
}
exports.isCompatibleWithJoinViewTeamPermissions = isCompatibleWithJoinViewTeamPermissions;
function hasNewPermissions(state) {
    var version = state.entities.general.serverVersion;
    // FIXME This must be changed to 4, 9, 0 before we generate the 4.9.0 release
    return helpers_1.isMinimumServerVersion(version, 4, 9, 0) ||
        (version.indexOf('dev') !== -1 && helpers_1.isMinimumServerVersion(version, 4, 8, 0)) ||
        (version.match(/^4.8.\d.\d\d\d\d.*$/) !== null && helpers_1.isMinimumServerVersion(version, 4, 8, 0));
}
exports.hasNewPermissions = hasNewPermissions;
exports.canUploadFilesOnMobile = reselect_1.createSelector(getConfig, getLicense, function (config, license) {
    // Defaults to true if either setting doesn't exist
    return config.EnableFileAttachments !== 'false' &&
        (license.IsLicensed === 'false' || license.Compliance === 'false' || config.EnableMobileFileUpload !== 'false');
});
exports.canDownloadFilesOnMobile = reselect_1.createSelector(getConfig, getLicense, function (config, license) {
    // Defaults to true if the setting doesn't exist
    return license.IsLicensed === 'false' || license.Compliance === 'false' || config.EnableMobileFileDownload !== 'false';
});
exports.getAutolinkedUrlSchemes = reselect_1.createSelector(getConfig, function (config) {
    if (!config.CustomUrlSchemes) {
        return constants_1.General.DEFAULT_AUTOLINKED_URL_SCHEMES;
    }
    return tslib_1.__spread(constants_1.General.DEFAULT_AUTOLINKED_URL_SCHEMES, config.CustomUrlSchemes.split(','));
});
exports.getServerVersion = function (state) {
    return state.entities.general.serverVersion;
};
//# sourceMappingURL=general.js.map

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect = tslib_1.__importStar(__webpack_require__(5));
var shallow_equals_1 = tslib_1.__importDefault(__webpack_require__(25));
function memoizeResult(func) {
    var lastArgs = null;
    var lastResult = null; // we reference arguments instead of spreading them for performance reasons
    return function shallowCompare() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (!shallow_equals_1.default(lastArgs, args)) {
            //eslint-disable-line prefer-rest-params
            // apply arguments instead of spreading for performance.
            var result = Reflect.apply(func, null, arguments); //eslint-disable-line prefer-rest-params
            if (!shallow_equals_1.default(lastResult, result)) {
                lastResult = result;
            }
        }
        lastArgs = arguments; //eslint-disable-line prefer-rest-params
        return lastResult;
    };
}
exports.memoizeResult = memoizeResult;
// Use this selector when you want a shallow comparison of the arguments and you want to memoize the result
// try and use this only when your selector returns an array of ids
exports.createIdsSelector = reselect.createSelectorCreator(memoizeResult);
// Use this selector when you want a shallow comparison of the arguments and you don't need to memoize the result
exports.createShallowSelector = reselect.createSelectorCreator(reselect.defaultMemoize, shallow_equals_1.default);
// isMinimumServerVersion will return true if currentVersion is equal to higher or than the
// the provided minimum version. A non-equal major version will ignore minor and dot
// versions, and a non-equal minor version will ignore dot version.
// currentVersion is a string, e.g '4.6.0'
// minMajorVersion, minMinorVersion, minDotVersion are integers
exports.isMinimumServerVersion = function (currentVersion, minMajorVersion, minMinorVersion, minDotVersion) {
    if (minMajorVersion === void 0) { minMajorVersion = 0; }
    if (minMinorVersion === void 0) { minMinorVersion = 0; }
    if (minDotVersion === void 0) { minDotVersion = 0; }
    if (!currentVersion || typeof currentVersion !== 'string') {
        return false;
    }
    var split = currentVersion.split('.');
    var major = parseInt(split[0], 10);
    var minor = parseInt(split[1] || '0', 10);
    var dot = parseInt(split[2] || '0', 10);
    if (major > minMajorVersion) {
        return true;
    }
    if (major < minMajorVersion) {
        return false;
    }
    // Major version is equal, check minor
    if (minor > minMinorVersion) {
        return true;
    }
    if (minor < minMinorVersion) {
        return false;
    }
    // Minor version is equal, check dot
    if (dot > minDotVersion) {
        return true;
    }
    if (dot < minDotVersion) {
        return false;
    }
    // Dot version is equal
    return true;
};
// Generates a RFC-4122 version 4 compliant globally unique identifier.
function generateId() {
    // implementation taken from http://stackoverflow.com/a/2117523
    var id = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
    id = id.replace(/[xy]/g, function (c) {
        var r = Math.floor(Math.random() * 16);
        var v;
        if (c === 'x') {
            v = r;
        }
        else {
            // eslint-disable-next-line no-mixed-operators
            v = r & 0x3 | 0x8;
        }
        return v.toString(16);
    });
    return id;
}
exports.generateId = generateId;
function isEmail(email) {
    // writing a regex to match all valid email addresses is really, really hard. (see http://stackoverflow.com/a/201378)
    // this regex ensures:
    // - at least one character that is not a space, comma, or @ symbol
    // - followed by a single @ symbol
    // - followed by at least one character that is not a space, comma, or @ symbol
    // this prevents <Outlook Style> outlook.style@domain.com addresses and multiple comma-separated addresses from being accepted
    return (/^[^ ,@]+@[^ ,@]+$/).test(email);
}
exports.isEmail = isEmail;
function buildQueryString(parameters) {
    var keys = Object.keys(parameters);
    if (keys.length === 0) {
        return '';
    }
    var query = '?';
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        query += key + '=' + encodeURIComponent(parameters[key]);
        if (i < keys.length - 1) {
            query += '&';
        }
    }
    return query;
}
exports.buildQueryString = buildQueryString;
//# sourceMappingURL=helpers.js.map

/***/ }),
/* 25 */
/***/ (function(module, exports) {

module.exports = shallow

function shallow(a, b, compare) {
  var aIsNull = a === null
  var bIsNull = b === null

  if (aIsNull !== bIsNull) return false

  var aIsArray = Array.isArray(a)
  var bIsArray = Array.isArray(b)

  if (aIsArray !== bIsArray) return false

  var aTypeof = typeof a
  var bTypeof = typeof b

  if (aTypeof !== bTypeof) return false
  if (flat(aTypeof)) return compare
    ? compare(a, b)
    : a === b

  return aIsArray
    ? shallowArray(a, b, compare)
    : shallowObject(a, b, compare)
}

function shallowArray(a, b, compare) {
  var l = a.length
  if (l !== b.length) return false

  if (compare) {
    for (var i = 0; i < l; i++)
      if (!compare(a[i], b[i])) return false
  } else {
    for (var i = 0; i < l; i++) {
      if (a[i] !== b[i]) return false
    }
  }

  return true
}

function shallowObject(a, b, compare) {
  var ka = 0
  var kb = 0

  if (compare) {
    for (var key in a) {
      if (
        a.hasOwnProperty(key) &&
        !compare(a[key], b[key])
      ) return false

      ka++
    }
  } else {
    for (var key in a) {
      if (
        a.hasOwnProperty(key) &&
        a[key] !== b[key]
      ) return false

      ka++
    }
  }

  for (var key in b) {
    if (b.hasOwnProperty(key)) kb++
  }

  return ka === kb
}

function flat(type) {
  return (
    type !== 'function' &&
    type !== 'object'
  )
}


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect = tslib_1.__importStar(__webpack_require__(5));
var constants_1 = __webpack_require__(6);
var general_1 = __webpack_require__(23);
var teams_1 = __webpack_require__(27);
var helpers_1 = __webpack_require__(24);
var preference_utils_1 = __webpack_require__(32);
function getMyPreferences(state) {
    return state.entities.preferences.myPreferences;
}
exports.getMyPreferences = getMyPreferences;
function get(state, category, name, defaultValue) {
    if (defaultValue === void 0) { defaultValue = ''; }
    var key = preference_utils_1.getPreferenceKey(category, name);
    var prefs = getMyPreferences(state);
    if (!(key in prefs)) {
        return defaultValue;
    }
    return prefs[key].value;
}
exports.get = get;
function getBool(state, category, name, defaultValue) {
    if (defaultValue === void 0) { defaultValue = false; }
    var value = get(state, category, name, String(defaultValue));
    return value !== 'false';
}
exports.getBool = getBool;
function getInt(state, category, name, defaultValue) {
    if (defaultValue === void 0) { defaultValue = 0; }
    var value = get(state, category, name, defaultValue);
    return parseInt(value, 10);
}
exports.getInt = getInt;
function makeGetCategory() {
    return reselect.createSelector(getMyPreferences, function (state, category) { return category; }, function (preferences, category) {
        var prefix = category + '--';
        var prefsInCategory = [];
        for (var key in preferences) {
            if (key.startsWith(prefix)) {
                prefsInCategory.push(preferences[key]);
            }
        }
        return prefsInCategory;
    });
}
exports.makeGetCategory = makeGetCategory;
var getDirectShowCategory = makeGetCategory();
function getDirectShowPreferences(state) {
    return getDirectShowCategory(state, constants_1.Preferences.CATEGORY_DIRECT_CHANNEL_SHOW);
}
exports.getDirectShowPreferences = getDirectShowPreferences;
var getGroupShowCategory = makeGetCategory();
function getGroupShowPreferences(state) {
    return getGroupShowCategory(state, constants_1.Preferences.CATEGORY_GROUP_CHANNEL_SHOW);
}
exports.getGroupShowPreferences = getGroupShowPreferences;
var getFavoritesCategory = makeGetCategory();
function getFavoritesPreferences(state) {
    var favorites = getFavoritesCategory(state, constants_1.Preferences.CATEGORY_FAVORITE_CHANNEL);
    return favorites.filter(function (f) { return f.value === 'true'; }).map(function (f) { return f.name; });
}
exports.getFavoritesPreferences = getFavoritesPreferences;
exports.getVisibleTeammate = reselect.createSelector(getDirectShowPreferences, function (direct) {
    return direct.filter(function (dm) { return dm.value === 'true' && dm.name; }).map(function (dm) { return dm.name; });
});
exports.getVisibleGroupIds = reselect.createSelector(getGroupShowPreferences, function (groups) {
    return groups.filter(function (dm) { return dm.value === 'true' && dm.name; }).map(function (dm) { return dm.name; });
});
exports.getTeammateNameDisplaySetting = reselect.createSelector(general_1.getConfig, getMyPreferences, function (config, preferences) {
    var key = preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_DISPLAY_SETTINGS, constants_1.Preferences.NAME_NAME_FORMAT);
    if (preferences[key]) {
        return preferences[key].value;
    }
    else if (config.TeammateNameDisplay) {
        return config.TeammateNameDisplay;
    }
    return constants_1.General.TEAMMATE_NAME_DISPLAY.SHOW_USERNAME;
});
var getThemePreference = reselect.createSelector(getMyPreferences, teams_1.getCurrentTeamId, function (myPreferences, currentTeamId) {
    // Prefer the user's current team-specific theme over the user's current global theme
    var themePreference;
    if (currentTeamId) {
        themePreference = myPreferences[preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_THEME, currentTeamId)];
    }
    if (!themePreference) {
        themePreference = myPreferences[preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_THEME, '')];
    }
    return themePreference;
});
var getDefaultTheme = reselect.createSelector(general_1.getConfig, function (config) {
    if (config.DefaultTheme) {
        var theme = constants_1.Preferences.THEMES[config.DefaultTheme];
        if (theme) {
            return theme;
        }
    }
    // If no config.DefaultTheme or value doesn't refer to a valid theme name...
    return constants_1.Preferences.THEMES.default;
});
exports.getTheme = helpers_1.createShallowSelector(getThemePreference, getDefaultTheme, function (themePreference, defaultTheme) {
    var e_1, _a;
    var theme;
    if (themePreference) {
        theme = themePreference.value;
    }
    else {
        theme = defaultTheme;
    }
    if (typeof theme === 'string') {
        // A custom theme will be a JSON-serialized object stored in a preference
        theme = JSON.parse(theme);
    }
    // At this point, the theme should be a plain object
    // If this is a system theme, find it in case the user's theme is missing any fields
    if (theme.type && theme.type !== 'custom') {
        var match = Object.values(constants_1.Preferences.THEMES).find(function (v) { return v.type === theme.type; });
        if (match) {
            if (!match.mentionBg) {
                match.mentionBg = match.mentionBj;
            }
            return match;
        }
    }
    try {
        for (var _b = tslib_1.__values(Object.keys(defaultTheme)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var key = _c.value;
            if (theme[key]) {
                // Fix a case where upper case theme colours are rendered as black
                theme[key] = theme[key].toLowerCase();
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    // Backwards compatability with old name
    if (!theme.mentionBg) {
        theme.mentionBg = theme.mentionBj;
    }
    return Object.assign({}, defaultTheme, theme);
});
function makeGetStyleFromTheme() {
    return reselect.createSelector(exports.getTheme, function (state, getStyleFromTheme) { return getStyleFromTheme; }, function (theme, getStyleFromTheme) {
        return getStyleFromTheme(theme);
    });
}
exports.makeGetStyleFromTheme = makeGetStyleFromTheme;
var defaultSidebarPrefs = {
    grouping: 'by_type',
    unreads_at_top: 'true',
    favorite_at_top: 'true',
    sorting: 'alpha',
};
exports.getSidebarPreferences = reselect.createSelector(function (state) {
    var config = general_1.getConfig(state);
    return config.ExperimentalGroupUnreadChannels !== constants_1.General.DISABLED && getBool(state, constants_1.Preferences.CATEGORY_SIDEBAR_SETTINGS, 'show_unread_section', config.ExperimentalGroupUnreadChannels === constants_1.General.DEFAULT_ON);
}, function (state) {
    return get(state, constants_1.Preferences.CATEGORY_SIDEBAR_SETTINGS, '', null);
}, function (showUnreadSection, sidebarPreference) {
    var sidebarPrefs = JSON.parse(sidebarPreference);
    if (sidebarPrefs === null) {
        // Support unread settings for old implementation
        sidebarPrefs = tslib_1.__assign(tslib_1.__assign({}, defaultSidebarPrefs), { unreads_at_top: showUnreadSection ? 'true' : 'false' });
    }
    return sidebarPrefs;
});
//# sourceMappingURL=preferences.js.map

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect = tslib_1.__importStar(__webpack_require__(5));
var constants_1 = __webpack_require__(6);
var general_1 = __webpack_require__(23);
var roles_helpers_1 = __webpack_require__(28);
var helpers_1 = __webpack_require__(24);
var user_utils_1 = __webpack_require__(29);
var team_utils_1 = __webpack_require__(31);
function getCurrentTeamId(state) {
    return state.entities.teams.currentTeamId;
}
exports.getCurrentTeamId = getCurrentTeamId;
exports.getTeamByName = reselect.createSelector(getTeams, function (state, name) { return name; }, function (teams, name) {
    return Object.values(teams).find(function (team) { return team.name === name; });
});
function getTeams(state) {
    return state.entities.teams.teams;
}
exports.getTeams = getTeams;
function getTeamStats(state) {
    return state.entities.teams.stats;
}
exports.getTeamStats = getTeamStats;
function getTeamMemberships(state) {
    return state.entities.teams.myMembers;
}
exports.getTeamMemberships = getTeamMemberships;
function getMembersInTeams(state) {
    return state.entities.teams.membersInTeam;
}
exports.getMembersInTeams = getMembersInTeams;
exports.getTeamsList = reselect.createSelector(getTeams, function (teams) {
    return Object.values(teams);
});
exports.getCurrentTeam = reselect.createSelector(getTeams, getCurrentTeamId, function (teams, currentTeamId) {
    return teams[currentTeamId];
});
function getTeam(state, id) {
    var teams = getTeams(state);
    return teams[id];
}
exports.getTeam = getTeam;
exports.getCurrentTeamMembership = reselect.createSelector(getCurrentTeamId, getTeamMemberships, function (currentTeamId, teamMemberships) {
    return teamMemberships[currentTeamId];
});
exports.isCurrentUserCurrentTeamAdmin = reselect.createSelector(exports.getCurrentTeamMembership, function (member) {
    if (member) {
        var roles = member.roles || '';
        return user_utils_1.isTeamAdmin(roles);
    }
    return false;
});
exports.getCurrentTeamUrl = reselect.createSelector(general_1.getCurrentUrl, exports.getCurrentTeam, function (state) { return general_1.getConfig(state).SiteURL; }, function (currentURL, currentTeam, siteURL) {
    var rootURL = "" + (currentURL || siteURL);
    if (!currentTeam) {
        return rootURL;
    }
    return rootURL + "/" + currentTeam.name;
});
exports.getCurrentRelativeTeamUrl = reselect.createSelector(exports.getCurrentTeam, function (currentTeam) {
    if (!currentTeam) {
        return '/';
    }
    return "/" + currentTeam.name;
});
exports.getCurrentTeamStats = reselect.createSelector(getCurrentTeamId, getTeamStats, function (currentTeamId, teamStats) {
    return teamStats[currentTeamId];
});
exports.getMyTeams = reselect.createSelector(getTeams, getTeamMemberships, function (teams, members) {
    return Object.values(teams).filter(function (t) { return members[t.id] && t.delete_at === 0; });
});
exports.getMyTeamMember = reselect.createSelector(getTeamMemberships, function (state, teamId) { return teamId; }, function (teamMemberships, teamId) {
    return teamMemberships[teamId] || {};
});
exports.getMembersInCurrentTeam = reselect.createSelector(getCurrentTeamId, getMembersInTeams, function (currentTeamId, teamMembers) {
    return teamMembers[currentTeamId];
});
function getTeamMember(state, teamId, userId) {
    var members = getMembersInTeams(state)[teamId];
    if (members) {
        return members[userId];
    }
    return null;
}
exports.getTeamMember = getTeamMember;
exports.getListableTeamIds = helpers_1.createIdsSelector(getTeams, getTeamMemberships, function (state) { return roles_helpers_1.haveISystemPermission(state, { permission: constants_1.Permissions.LIST_PUBLIC_TEAMS }); }, function (state) { return roles_helpers_1.haveISystemPermission(state, { permission: constants_1.Permissions.LIST_PRIVATE_TEAMS }); }, general_1.isCompatibleWithJoinViewTeamPermissions, function (teams, myMembers, canListPublicTeams, canListPrivateTeams, compatibleWithJoinViewTeamPermissions) {
    return Object.keys(teams).filter(function (id) {
        var team = teams[id];
        var member = myMembers[id];
        var canList = team.allow_open_invite;
        if (compatibleWithJoinViewTeamPermissions) {
            canList = (canListPrivateTeams && !team.allow_open_invite) || (canListPublicTeams && team.allow_open_invite);
        }
        return team.delete_at === 0 && canList && !member;
    });
});
exports.getListableTeams = reselect.createSelector(getTeams, exports.getListableTeamIds, function (teams, listableTeamIds) {
    return listableTeamIds.map(function (id) { return teams[id]; });
});
exports.getSortedListableTeams = reselect.createSelector(getTeams, exports.getListableTeamIds, function (state, locale) { return locale; }, function (teams, listableTeamIds, locale) {
    var e_1, _a;
    var listableTeams = {};
    try {
        for (var listableTeamIds_1 = tslib_1.__values(listableTeamIds), listableTeamIds_1_1 = listableTeamIds_1.next(); !listableTeamIds_1_1.done; listableTeamIds_1_1 = listableTeamIds_1.next()) {
            var id = listableTeamIds_1_1.value;
            listableTeams[id] = teams[id];
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (listableTeamIds_1_1 && !listableTeamIds_1_1.done && (_a = listableTeamIds_1.return)) _a.call(listableTeamIds_1);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return Object.values(listableTeams).sort(team_utils_1.sortTeamsWithLocale(locale));
});
exports.getJoinableTeamIds = helpers_1.createIdsSelector(getTeams, getTeamMemberships, function (state) { return roles_helpers_1.haveISystemPermission(state, { permission: constants_1.Permissions.JOIN_PUBLIC_TEAMS }); }, function (state) { return roles_helpers_1.haveISystemPermission(state, { permission: constants_1.Permissions.JOIN_PRIVATE_TEAMS }); }, general_1.isCompatibleWithJoinViewTeamPermissions, function (teams, myMembers, canJoinPublicTeams, canJoinPrivateTeams, compatibleWithJoinViewTeamPermissions) {
    return Object.keys(teams).filter(function (id) {
        var team = teams[id];
        var member = myMembers[id];
        var canJoin = team.allow_open_invite;
        if (compatibleWithJoinViewTeamPermissions) {
            canJoin = (canJoinPrivateTeams && !team.allow_open_invite) || (canJoinPublicTeams && team.allow_open_invite);
        }
        return team.delete_at === 0 && canJoin && !member;
    });
});
exports.getJoinableTeams = reselect.createSelector(getTeams, exports.getJoinableTeamIds, function (teams, joinableTeamIds) {
    return joinableTeamIds.map(function (id) { return teams[id]; });
});
exports.getSortedJoinableTeams = reselect.createSelector(getTeams, exports.getJoinableTeamIds, function (state, locale) { return locale; }, function (teams, joinableTeamIds, locale) {
    var e_2, _a;
    var joinableTeams = {};
    try {
        for (var joinableTeamIds_1 = tslib_1.__values(joinableTeamIds), joinableTeamIds_1_1 = joinableTeamIds_1.next(); !joinableTeamIds_1_1.done; joinableTeamIds_1_1 = joinableTeamIds_1.next()) {
            var id = joinableTeamIds_1_1.value;
            joinableTeams[id] = teams[id];
        }
    }
    catch (e_2_1) { e_2 = { error: e_2_1 }; }
    finally {
        try {
            if (joinableTeamIds_1_1 && !joinableTeamIds_1_1.done && (_a = joinableTeamIds_1.return)) _a.call(joinableTeamIds_1);
        }
        finally { if (e_2) throw e_2.error; }
    }
    return Object.values(joinableTeams).sort(team_utils_1.sortTeamsWithLocale(locale));
});
exports.getMySortedTeamIds = helpers_1.createIdsSelector(exports.getMyTeams, function (state, locale) { return locale; }, function (teams, locale) {
    return teams.sort(team_utils_1.sortTeamsWithLocale(locale)).map(function (t) { return t.id; });
});
exports.getMyTeamsCount = reselect.createSelector(exports.getMyTeams, function (teams) {
    return teams.length;
});
// returns the badge number to show (excluding the current team)
// > 0 means is returning the mention count
// 0 means that there are no unread messages
// -1 means that there are unread messages but no mentions
exports.getChannelDrawerBadgeCount = reselect.createSelector(getCurrentTeamId, getTeamMemberships, function (currentTeamId, teamMembers) {
    var mentionCount = 0;
    var messageCount = 0;
    Object.values(teamMembers).forEach(function (m) {
        if (m.team_id !== currentTeamId) {
            mentionCount += (m.mention_count || 0);
            messageCount += (m.msg_count || 0);
        }
    });
    var badgeCount = 0;
    if (mentionCount) {
        badgeCount = mentionCount;
    }
    else if (messageCount) {
        badgeCount = -1;
    }
    return badgeCount;
});
// returns the badge for a team
// > 0 means is returning the mention count
// 0 means that there are no unread messages
// -1 means that there are unread messages but no mentions
function makeGetBadgeCountForTeamId() {
    return reselect.createSelector(getTeamMemberships, function (state, id) { return id; }, function (members, teamId) {
        var member = members[teamId];
        var badgeCount = 0;
        if (member) {
            if (member.mention_count) {
                badgeCount = member.mention_count;
            }
            else if (member.msg_count) {
                badgeCount = -1;
            }
        }
        return badgeCount;
    });
}
exports.makeGetBadgeCountForTeamId = makeGetBadgeCountForTeamId;
//# sourceMappingURL=teams.js.map

/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect = tslib_1.__importStar(__webpack_require__(5));
var common_1 = __webpack_require__(22);
function getRoles(state) {
    return state.entities.roles.roles;
}
exports.getRoles = getRoles;
exports.getMySystemRoles = reselect.createSelector(common_1.getCurrentUser, function (user) {
    if (user) {
        return new Set(user.roles.split(' '));
    }
    return new Set();
});
exports.getMySystemPermissions = reselect.createSelector(exports.getMySystemRoles, getRoles, function (mySystemRoles, roles) {
    var e_1, _a, e_2, _b;
    var permissions = new Set();
    try {
        for (var mySystemRoles_1 = tslib_1.__values(mySystemRoles), mySystemRoles_1_1 = mySystemRoles_1.next(); !mySystemRoles_1_1.done; mySystemRoles_1_1 = mySystemRoles_1.next()) {
            var roleName = mySystemRoles_1_1.value;
            if (roles[roleName]) {
                try {
                    for (var _c = (e_2 = void 0, tslib_1.__values(roles[roleName].permissions)), _d = _c.next(); !_d.done; _d = _c.next()) {
                        var permission = _d.value;
                        permissions.add(permission);
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (mySystemRoles_1_1 && !mySystemRoles_1_1.done && (_a = mySystemRoles_1.return)) _a.call(mySystemRoles_1);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return permissions;
});
exports.haveISystemPermission = reselect.createSelector(exports.getMySystemPermissions, function (state, options) { return options.permission; }, function (permissions, permission) {
    return permissions.has(permission);
});
//# sourceMappingURL=roles_helpers.js.map

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var constants_1 = __webpack_require__(6);
var i18n_utils_1 = __webpack_require__(30);
function getFullName(user) {
    if (user.first_name && user.last_name) {
        return user.first_name + ' ' + user.last_name;
    }
    else if (user.first_name) {
        return user.first_name;
    }
    else if (user.last_name) {
        return user.last_name;
    }
    return '';
}
exports.getFullName = getFullName;
function displayUsername(user, teammateNameDisplay, useFallbackUsername, useAdminTemmateNameDisplaySetting, adminTeammateNameDisplaySetting) {
    if (useFallbackUsername === void 0) { useFallbackUsername = true; }
    if (useAdminTemmateNameDisplaySetting === void 0) { useAdminTemmateNameDisplaySetting = false; }
    if (adminTeammateNameDisplaySetting === void 0) { adminTeammateNameDisplaySetting = ''; }
    var name = useFallbackUsername ? i18n_utils_1.localizeMessage('channel_loader.someone', 'Someone') : '';
    var nameDisplay = useAdminTemmateNameDisplaySetting ? adminTeammateNameDisplaySetting : teammateNameDisplay;
    if (user) {
        if (nameDisplay === constants_1.Preferences.DISPLAY_PREFER_NICKNAME) {
            name = user.nickname || getFullName(user);
        }
        else if (nameDisplay === constants_1.Preferences.DISPLAY_PREFER_FULL_NAME) {
            name = getFullName(user);
        }
        else {
            name = user.username;
        }
        if (!name || name.trim().length === 0) {
            name = user.username;
        }
    }
    return name;
}
exports.displayUsername = displayUsername;
function rolesIncludePermission(roles, permission) {
    var rolesArray = roles.split(' ');
    return rolesArray.includes(permission);
}
exports.rolesIncludePermission = rolesIncludePermission;
function isAdmin(roles) {
    return isSystemAdmin(roles) || isTeamAdmin(roles);
}
exports.isAdmin = isAdmin;
function isTeamAdmin(roles) {
    return rolesIncludePermission(roles, constants_1.General.TEAM_ADMIN_ROLE);
}
exports.isTeamAdmin = isTeamAdmin;
function isSystemAdmin(roles) {
    return rolesIncludePermission(roles, constants_1.General.SYSTEM_ADMIN_ROLE);
}
exports.isSystemAdmin = isSystemAdmin;
function isChannelAdmin(roles) {
    return rolesIncludePermission(roles, constants_1.General.CHANNEL_ADMIN_ROLE);
}
exports.isChannelAdmin = isChannelAdmin;
function hasUserAccessTokenRole(roles) {
    return rolesIncludePermission(roles, constants_1.General.SYSTEM_USER_ACCESS_TOKEN_ROLE);
}
exports.hasUserAccessTokenRole = hasUserAccessTokenRole;
function hasPostAllRole(roles) {
    return rolesIncludePermission(roles, constants_1.General.SYSTEM_POST_ALL_ROLE);
}
exports.hasPostAllRole = hasPostAllRole;
function hasPostAllPublicRole(roles) {
    return rolesIncludePermission(roles, constants_1.General.SYSTEM_POST_ALL_PUBLIC_ROLE);
}
exports.hasPostAllPublicRole = hasPostAllPublicRole;
function profileListToMap(profileList) {
    var profiles = {};
    for (var i = 0; i < profileList.length; i++) {
        profiles[profileList[i].id] = profileList[i];
    }
    return profiles;
}
exports.profileListToMap = profileListToMap;
function removeUserFromList(userId, list) {
    for (var i = list.length - 1; i >= 0; i--) {
        if (list[i].id === userId) {
            list.splice(i, 1);
            return list;
        }
    }
    return list;
}
exports.removeUserFromList = removeUserFromList;
// Splits the term by a splitStr and composes a list of the parts of
// the split concatenated with the rest, forming a set of suggesitons
// matchable with startsWith
//
// E.g.: for "one.two.three" by "." it would yield
// ["one.two.three", ".two.three", "two.three", ".three", "three"]
function getSuggestionsSplitBy(term, splitStr) {
    var splitTerm = term.split(splitStr);
    var initialSuggestions = splitTerm.map(function (st, i) { return splitTerm.slice(i).join(splitStr); });
    var suggestions = [];
    if (splitStr === ' ') {
        suggestions = initialSuggestions;
    }
    else {
        suggestions = initialSuggestions.reduce(function (acc, val) {
            if (acc.length === 0) {
                acc.push(val);
            }
            else {
                acc.push(splitStr + val, val);
            }
            return acc;
        }, []);
    }
    return suggestions;
}
exports.getSuggestionsSplitBy = getSuggestionsSplitBy;
function getSuggestionsSplitByMultiple(term, splitStrs) {
    var suggestions = splitStrs.reduce(function (acc, val) {
        getSuggestionsSplitBy(term, val).forEach(function (suggestion) { return acc.add(suggestion); });
        return acc;
    }, new Set());
    return tslib_1.__spread(suggestions);
}
exports.getSuggestionsSplitByMultiple = getSuggestionsSplitByMultiple;
function filterProfilesMatchingTerm(users, term) {
    var lowercasedTerm = term.toLowerCase();
    var trimmedTerm = lowercasedTerm;
    if (trimmedTerm.startsWith('@')) {
        trimmedTerm = trimmedTerm.substr(1);
    }
    return users.filter(function (user) {
        if (!user) {
            return false;
        }
        var profileSuggestions = [];
        var usernameSuggestions = getSuggestionsSplitByMultiple((user.username || '').toLowerCase(), constants_1.General.AUTOCOMPLETE_SPLIT_CHARACTERS);
        profileSuggestions.push.apply(profileSuggestions, tslib_1.__spread(usernameSuggestions));
        var first = (user.first_name || '').toLowerCase();
        var last = (user.last_name || '').toLowerCase();
        var full = first + ' ' + last;
        profileSuggestions.push(first, last, full);
        profileSuggestions.push((user.nickname || '').toLowerCase());
        var email = (user.email || '').toLowerCase();
        profileSuggestions.push(email);
        profileSuggestions.push((user.nickname || '').toLowerCase());
        var split = email.split('@');
        if (split.length > 1) {
            profileSuggestions.push(split[1]);
        }
        return profileSuggestions.
            filter(function (suggestion) { return suggestion !== ''; }).
            some(function (suggestion) { return suggestion.startsWith(trimmedTerm); });
    });
}
exports.filterProfilesMatchingTerm = filterProfilesMatchingTerm;
function sortByUsername(a, b) {
    var nameA = a.username;
    var nameB = b.username;
    return nameA.localeCompare(nameB);
}
exports.sortByUsername = sortByUsername;
//# sourceMappingURL=user_utils.js.map

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var localizeFunction = null;
function setLocalizeFunction(func) {
    localizeFunction = func;
}
exports.setLocalizeFunction = setLocalizeFunction;
function localizeMessage(id, defaultMessage) {
    if (!localizeFunction) {
        return defaultMessage;
    }
    return localizeFunction(id, defaultMessage);
}
exports.localizeMessage = localizeMessage;
//# sourceMappingURL=i18n_utils.js.map

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var constants_1 = __webpack_require__(6);
function teamListToMap(teamList) {
    var teams = {};
    for (var i = 0; i < teamList.length; i++) {
        teams[teamList[i].id] = teamList[i];
    }
    return teams;
}
exports.teamListToMap = teamListToMap;
function sortTeamsWithLocale(locale) {
    return function (a, b) {
        if (a.display_name !== b.display_name) {
            return a.display_name.toLowerCase().localeCompare(b.display_name.toLowerCase(), locale || constants_1.General.DEFAULT_LOCALE, { numeric: true });
        }
        return a.name.toLowerCase().localeCompare(b.name.toLowerCase(), locale || constants_1.General.DEFAULT_LOCALE, { numeric: true });
    };
}
exports.sortTeamsWithLocale = sortTeamsWithLocale;
//# sourceMappingURL=team_utils.js.map

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
function getPreferenceKey(category, name) {
    return category + "--" + name;
}
exports.getPreferenceKey = getPreferenceKey;
function getPreferencesByCategory(myPreferences, category) {
    var prefix = category + "--";
    var preferences = new Map();
    Object.keys(myPreferences).forEach(function (key) {
        if (key.startsWith(prefix)) {
            preferences.set(key.substring(prefix.length), myPreferences[key]);
        }
    });
    return preferences;
}
exports.getPreferencesByCategory = getPreferencesByCategory;
//# sourceMappingURL=preference_utils.js.map

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect_1 = __webpack_require__(5);
var common_1 = __webpack_require__(22);
var preferences_1 = __webpack_require__(26);
var helpers_1 = __webpack_require__(24);
var constants_1 = __webpack_require__(6);
var post_utils_1 = __webpack_require__(34);
var preference_utils_1 = __webpack_require__(32);
function getAllPosts(state) {
    return state.entities.posts.posts;
}
exports.getAllPosts = getAllPosts;
function getPost(state, postId) {
    return getAllPosts(state)[postId];
}
exports.getPost = getPost;
function getPostsInThread(state) {
    return state.entities.posts.postsInThread;
}
exports.getPostsInThread = getPostsInThread;
function getReactionsForPosts(state) {
    return state.entities.posts.reactions;
}
exports.getReactionsForPosts = getReactionsForPosts;
function makeGetReactionsForPost() {
    return reselect_1.createSelector(getReactionsForPosts, function (state, postId) { return postId; }, function (reactions, postId) {
        if (reactions[postId]) {
            return reactions[postId];
        }
        return null;
    });
}
exports.makeGetReactionsForPost = makeGetReactionsForPost;
function getOpenGraphMetadata(state) {
    return state.entities.posts.openGraph;
}
exports.getOpenGraphMetadata = getOpenGraphMetadata;
function getOpenGraphMetadataForUrl(state, url) {
    return state.entities.posts.openGraph[url];
}
exports.getOpenGraphMetadataForUrl = getOpenGraphMetadataForUrl;
// getPostIdsInCurrentChannel returns the IDs of posts loaded at the bottom of the channel. It does not include older
// posts such as those loaded by viewing a thread or a permalink.
function getPostIdsInCurrentChannel(state) {
    return getPostIdsInChannel(state, state.entities.channels.currentChannelId);
}
exports.getPostIdsInCurrentChannel = getPostIdsInCurrentChannel;
// getPostsInCurrentChannel returns the posts loaded at the bottom of the channel. It does not include older posts
// such as those loaded by viewing a thread or a permalink.
exports.getPostsInCurrentChannel = (function () {
    var getPostsInChannel = makeGetPostsInChannel();
    return function (state) { return getPostsInChannel(state, state.entities.channels.currentChannelId, -1); };
})();
function makeGetPostIdsForThread() {
    return helpers_1.createIdsSelector(getAllPosts, function (state, rootId) { return state.entities.posts.postsInThread[rootId] || []; }, function (state, rootId) { return state.entities.posts.posts[rootId]; }, function (posts, postsForThread, rootPost) {
        var thread = [];
        if (rootPost) {
            thread.push(rootPost);
        }
        postsForThread.forEach(function (id) {
            var post = posts[id];
            if (post) {
                thread.push(post);
            }
        });
        thread.sort(post_utils_1.comparePosts);
        return thread.map(function (post) { return post.id; });
    });
}
exports.makeGetPostIdsForThread = makeGetPostIdsForThread;
function makeGetPostsChunkAroundPost() {
    return helpers_1.createIdsSelector(function (state, postId, channelId) { return state.entities.posts.postsInChannel[channelId]; }, function (state, postId) { return postId; }, function (postsForChannel, postId) {
        var e_1, _a;
        if (!postsForChannel) {
            return null;
        }
        var postChunk;
        try {
            for (var postsForChannel_1 = tslib_1.__values(postsForChannel), postsForChannel_1_1 = postsForChannel_1.next(); !postsForChannel_1_1.done; postsForChannel_1_1 = postsForChannel_1.next()) {
                var block = postsForChannel_1_1.value;
                var index = block.order.indexOf(postId);
                if (index === -1) {
                    continue;
                }
                postChunk = block;
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (postsForChannel_1_1 && !postsForChannel_1_1.done && (_a = postsForChannel_1.return)) _a.call(postsForChannel_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return postChunk;
    });
}
exports.makeGetPostsChunkAroundPost = makeGetPostsChunkAroundPost;
function makeGetPostIdsAroundPost() {
    var getPostsChunkAroundPost = makeGetPostsChunkAroundPost();
    return helpers_1.createIdsSelector(function (state, postId, channelId) { return getPostsChunkAroundPost(state, postId, channelId); }, function (state, postId) { return postId; }, function (state, postId, channelId, options) { return options && options.postsBeforeCount; }, function (state, postId, channelId, options) { return options && options.postsAfterCount; }, function (postsChunk, postId, postsBeforeCount, postsAfterCount) {
        if (postsBeforeCount === void 0) { postsBeforeCount = constants_1.Posts.POST_CHUNK_SIZE / 2; }
        if (postsAfterCount === void 0) { postsAfterCount = constants_1.Posts.POST_CHUNK_SIZE / 2; }
        if (!postsChunk || !postsChunk.order) {
            return null;
        }
        var postIds = postsChunk.order;
        var index = postIds.indexOf(postId);
        // Remember that posts that come after the post have a smaller index
        var minPostIndex = postsAfterCount === -1 ? 0 : Math.max(index - postsAfterCount, 0);
        var maxPostIndex = postsBeforeCount === -1 ? postIds.length : Math.min(index + postsBeforeCount + 1, postIds.length); // Needs the extra 1 to include the focused post
        return postIds.slice(minPostIndex, maxPostIndex);
    });
}
exports.makeGetPostIdsAroundPost = makeGetPostIdsAroundPost;
function formatPostInChannel(post, previousPost, index, allPosts, postsInThread, postIds, currentUser, focusedPostId) {
    var e_2, _a;
    var isFirstReply = false;
    var isLastReply = false;
    var highlight = false;
    var commentedOnPost;
    if (post.id === focusedPostId) {
        highlight = true;
    }
    if (post.root_id) {
        if (previousPost && previousPost.root_id !== post.root_id) {
            // Post is the first reply in a list of consecutive replies
            isFirstReply = true;
            if (previousPost && previousPost.id !== post.root_id) {
                commentedOnPost = allPosts[post.root_id];
            }
        }
        if (index - 1 < 0 || allPosts[postIds[index - 1]].root_id !== post.root_id) {
            // Post is the last reply in a list of consecutive replies
            isLastReply = true;
        }
    }
    var previousPostIsComment = false;
    if (previousPost && previousPost.root_id) {
        previousPostIsComment = true;
    }
    var postFromWebhook = Boolean(post.props && post.props.from_webhook);
    var prevPostFromWebhook = Boolean(previousPost && previousPost.props && previousPost.props.from_webhook);
    var consecutivePostByUser = false;
    if (previousPost &&
        previousPost.user_id === post.user_id &&
        post.create_at - previousPost.create_at <= constants_1.Posts.POST_COLLAPSE_TIMEOUT &&
        !postFromWebhook && !prevPostFromWebhook &&
        !post_utils_1.isSystemMessage(post) && !post_utils_1.isSystemMessage(previousPost)) {
        // The last post and this post were made by the same user within some time
        consecutivePostByUser = true;
    }
    var threadRepliedToByCurrentUser = false;
    var replyCount = 0;
    var isCommentMention = false;
    if (currentUser) {
        var rootId = post.root_id || post.id;
        var threadIds = postsInThread[rootId] || [];
        try {
            for (var threadIds_1 = tslib_1.__values(threadIds), threadIds_1_1 = threadIds_1.next(); !threadIds_1_1.done; threadIds_1_1 = threadIds_1.next()) {
                var pid = threadIds_1_1.value;
                var p = allPosts[pid];
                if (!p) {
                    continue;
                }
                if (p.user_id === currentUser.id) {
                    threadRepliedToByCurrentUser = true;
                }
                if (!post_utils_1.isPostEphemeral(p)) {
                    replyCount += 1;
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (threadIds_1_1 && !threadIds_1_1.done && (_a = threadIds_1.return)) _a.call(threadIds_1);
            }
            finally { if (e_2) throw e_2.error; }
        }
        var rootPost = allPosts[rootId];
        isCommentMention = post_utils_1.isPostCommentMention({ post: post, currentUser: currentUser, threadRepliedToByCurrentUser: threadRepliedToByCurrentUser, rootPost: rootPost });
    }
    return tslib_1.__assign(tslib_1.__assign({}, post), { isFirstReply: isFirstReply,
        isLastReply: isLastReply,
        previousPostIsComment: previousPostIsComment,
        commentedOnPost: commentedOnPost,
        consecutivePostByUser: consecutivePostByUser,
        replyCount: replyCount,
        isCommentMention: isCommentMention,
        highlight: highlight });
}
// makeGetPostsInChannel creates a selector that returns up to the given number of posts loaded at the bottom of the
// given channel. It does not include older posts such as those loaded by viewing a thread or a permalink.
function makeGetPostsInChannel() {
    return reselect_1.createSelector(getAllPosts, getPostsInThread, function (state, channelId) { return getPostIdsInChannel(state, channelId); }, common_1.getCurrentUser, preferences_1.getMyPreferences, function (state, channelId, numPosts) { return numPosts || constants_1.Posts.POST_CHUNK_SIZE; }, function (allPosts, postsInThread, allPostIds, currentUser, myPreferences, numPosts) {
        if (!allPostIds) {
            return null;
        }
        var posts = [];
        var joinLeavePref = myPreferences[preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_ADVANCED_SETTINGS, constants_1.Preferences.ADVANCED_FILTER_JOIN_LEAVE)];
        var showJoinLeave = joinLeavePref ? joinLeavePref.value !== 'false' : true;
        var postIds = numPosts === -1 ? allPostIds : allPostIds.slice(0, numPosts);
        for (var i = 0; i < postIds.length; i++) {
            var post = allPosts[postIds[i]];
            if (post_utils_1.shouldFilterJoinLeavePost(post, showJoinLeave, currentUser ? currentUser.username : '')) {
                continue;
            }
            var previousPost = allPosts[postIds[i + 1]] || null;
            posts.push(formatPostInChannel(post, previousPost, i, allPosts, postsInThread, postIds, currentUser, ''));
        }
        return posts;
    });
}
exports.makeGetPostsInChannel = makeGetPostsInChannel;
function makeGetPostsAroundPost() {
    var getPostIdsAroundPost = makeGetPostIdsAroundPost();
    var options = {
        postsBeforeCount: -1,
        postsAfterCount: constants_1.Posts.POST_CHUNK_SIZE / 2,
    };
    return reselect_1.createSelector(function (state, focusedPostId, channelId) { return getPostIdsAroundPost(state, focusedPostId, channelId, options); }, getAllPosts, getPostsInThread, function (state, focusedPostId) { return focusedPostId; }, common_1.getCurrentUser, preferences_1.getMyPreferences, function (postIds, allPosts, postsInThread, focusedPostId, currentUser, myPreferences) {
        if (!postIds || !currentUser) {
            return null;
        }
        var posts = [];
        var joinLeavePref = myPreferences[preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_ADVANCED_SETTINGS, constants_1.Preferences.ADVANCED_FILTER_JOIN_LEAVE)];
        var showJoinLeave = joinLeavePref ? joinLeavePref.value !== 'false' : true;
        for (var i = 0; i < postIds.length; i++) {
            var post = allPosts[postIds[i]];
            if (post_utils_1.shouldFilterJoinLeavePost(post, showJoinLeave, currentUser.username)) {
                continue;
            }
            var previousPost = allPosts[postIds[i + 1]] || null;
            var formattedPost = formatPostInChannel(post, previousPost, i, allPosts, postsInThread, postIds, currentUser, focusedPostId);
            posts.push(formattedPost);
        }
        return posts;
    });
}
exports.makeGetPostsAroundPost = makeGetPostsAroundPost;
// Returns a function that creates a creates a selector that will get the posts for a given thread.
// That selector will take a props object (containing a rootId field) as its
// only argument and will be memoized based on that argument.
function makeGetPostsForThread() {
    return reselect_1.createSelector(getAllPosts, function (state, _a) {
        var rootId = _a.rootId;
        return state.entities.posts.postsInThread[rootId] || [];
    }, function (state, _a) {
        var rootId = _a.rootId;
        return state.entities.posts.posts[rootId];
    }, function (posts, postsForThread, rootPost) {
        var thread = [];
        if (rootPost) {
            thread.push(rootPost);
        }
        postsForThread.forEach(function (id) {
            var post = posts[id];
            if (post) {
                thread.push(post);
            }
        });
        thread.sort(post_utils_1.comparePosts);
        return thread;
    });
}
exports.makeGetPostsForThread = makeGetPostsForThread;
function makeGetCommentCountForPost() {
    return reselect_1.createSelector(getAllPosts, function (state, _a) {
        var post = _a.post;
        return state.entities.posts.postsInThread[post ? post.id : ''] || [];
    }, function (state, props) { return props; }, function (posts, postsForThread, _a) {
        var currentPost = _a.post;
        if (!currentPost) {
            return 0;
        }
        var count = 0;
        postsForThread.forEach(function (id) {
            var post = posts[id];
            if (post && post.state !== constants_1.Posts.POST_DELETED && !post_utils_1.isPostEphemeral(post)) {
                count += 1;
            }
        });
        return count;
    });
}
exports.makeGetCommentCountForPost = makeGetCommentCountForPost;
exports.getSearchResults = reselect_1.createSelector(getAllPosts, function (state) { return state.entities.search.results; }, function (posts, postIds) {
    if (!postIds) {
        return [];
    }
    return postIds.map(function (id) { return posts[id]; });
});
// Returns the matched text from the search results, if the server has provided them.
// These matches will only be present if the server is running Mattermost 5.1 or higher
// with Elasticsearch enabled to search posts. Otherwise, null will be returned.
function getSearchMatches(state) {
    return state.entities.search.matches;
}
exports.getSearchMatches = getSearchMatches;
function makeGetMessageInHistoryItem(type) {
    return reselect_1.createSelector(function (state) { return state.entities.posts.messagesHistory; }, function (messagesHistory) {
        var idx = messagesHistory.index[type];
        var messages = messagesHistory.messages;
        if (idx >= 0 && messages && messages.length > idx) {
            return messages[idx];
        }
        return '';
    });
}
exports.makeGetMessageInHistoryItem = makeGetMessageInHistoryItem;
function makeGetPostsForIds() {
    return helpers_1.createIdsSelector(getAllPosts, function (state, postIds) { return postIds; }, function (allPosts, postIds) {
        if (!postIds) {
            return [];
        }
        return postIds.map(function (id) { return allPosts[id]; });
    });
}
exports.makeGetPostsForIds = makeGetPostsForIds;
exports.getLastPostPerChannel = reselect_1.createSelector(getAllPosts, function (state) { return state.entities.posts.postsInChannel; }, function (allPosts, postsInChannel) {
    var e_3, _a;
    var ret = {};
    try {
        for (var _b = tslib_1.__values(Object.entries(postsInChannel)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var _d = tslib_1.__read(_c.value, 2), channelId = _d[0], postsForChannel = _d[1];
            var recentBlock = (postsForChannel).find(function (block) { return block.recent; });
            if (!recentBlock) {
                continue;
            }
            var postId = recentBlock.order[0];
            if (allPosts.hasOwnProperty(postId)) {
                ret[channelId] = allPosts[postId];
            }
        }
    }
    catch (e_3_1) { e_3 = { error: e_3_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_3) throw e_3.error; }
    }
    return ret;
});
exports.getMostRecentPostIdInChannel = reselect_1.createSelector(getAllPosts, function (state, channelId) { return getPostIdsInChannel(state, channelId); }, preferences_1.getMyPreferences, function (posts, postIdsInChannel, preferences) {
    if (!postIdsInChannel) {
        return '';
    }
    var key = preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_ADVANCED_SETTINGS, constants_1.Preferences.ADVANCED_FILTER_JOIN_LEAVE);
    var allowSystemMessages = preferences[key] ? preferences[key].value === 'true' : true;
    if (!allowSystemMessages) {
        // return the most recent non-system message in the channel
        var postId = void 0;
        for (var i = 0; i < postIdsInChannel.length; i++) {
            var p = posts[postIdsInChannel[i]];
            if (!p.type || !p.type.startsWith(constants_1.Posts.SYSTEM_MESSAGE_PREFIX)) {
                postId = p.id;
                break;
            }
        }
        return postId;
    }
    // return the most recent message in the channel
    return postIdsInChannel[0];
});
exports.getLatestReplyablePostId = reselect_1.createSelector(exports.getPostsInCurrentChannel, function (posts) {
    if (!posts) {
        return '';
    }
    var latestReplyablePost = posts.find(function (post) { return post.state !== constants_1.Posts.POST_DELETED && !post_utils_1.isSystemMessage(post) && !post_utils_1.isPostEphemeral(post); });
    if (!latestReplyablePost) {
        return '';
    }
    return latestReplyablePost.id;
});
exports.getCurrentUsersLatestPost = reselect_1.createSelector(exports.getPostsInCurrentChannel, common_1.getCurrentUser, function (_, rootId) { return rootId; }, function (posts, currentUser, rootId) {
    if (!posts) {
        return null;
    }
    var lastPost = posts.find(function (post) {
        // don't edit webhook posts, deleted posts, or system messages
        if (post.user_id !== currentUser.id || post.props && post.props.from_webhook || post.state === constants_1.Posts.POST_DELETED || post_utils_1.isSystemMessage(post) || post_utils_1.isPostEphemeral(post) || post_utils_1.isPostPendingOrFailed(post)) {
            return false;
        }
        if (rootId) {
            return post.root_id === rootId || post.id === rootId;
        }
        return true;
    });
    return lastPost;
});
function getRecentPostsChunkInChannel(state, channelId) {
    var postsForChannel = state.entities.posts.postsInChannel[channelId];
    if (!postsForChannel) {
        return null;
    }
    return postsForChannel.find(function (block) { return block.recent; });
}
exports.getRecentPostsChunkInChannel = getRecentPostsChunkInChannel;
function getOldestPostsChunkInChannel(state, channelId) {
    var postsForChannel = state.entities.posts.postsInChannel[channelId];
    if (!postsForChannel) {
        return null;
    }
    return postsForChannel.find(function (block) { return block.oldest; });
}
exports.getOldestPostsChunkInChannel = getOldestPostsChunkInChannel;
// getPostIdsInChannel returns the IDs of posts loaded at the bottom of the given channel. It does not include older
// posts such as those loaded by viewing a thread or a permalink.
function getPostIdsInChannel(state, channelId) {
    var recentBlock = getRecentPostsChunkInChannel(state, channelId);
    if (!recentBlock) {
        return null;
    }
    return recentBlock.order;
}
exports.getPostIdsInChannel = getPostIdsInChannel;
function getPostsChunkInChannelAroundTime(state, channelId, timeStamp) {
    var postsEntity = state.entities.posts;
    var postsForChannel = postsEntity.postsInChannel[channelId];
    var posts = postsEntity.posts;
    if (!postsForChannel) {
        return null;
    }
    var blockAroundTimestamp = postsForChannel.find(function (block) {
        var order = block.order;
        var recentPostInBlock = posts[order[0]];
        var oldestPostInBlock = posts[order[order.length - 1]];
        if (recentPostInBlock && oldestPostInBlock) {
            return (recentPostInBlock.create_at >= timeStamp && oldestPostInBlock.create_at <= timeStamp);
        }
        return false;
    });
    return blockAroundTimestamp;
}
exports.getPostsChunkInChannelAroundTime = getPostsChunkInChannelAroundTime;
function getUnreadPostsChunk(state, channelId, timeStamp) {
    var postsEntity = state.entities.posts;
    var posts = postsEntity.posts;
    var recentChunk = getRecentPostsChunkInChannel(state, channelId);
    /* 1. lastViewedAt can be greater than the most recent chunk in case of edited posts etc.
          * return if recent block exists and oldest post is created after the last lastViewedAt timestamp
          i.e all posts are read and the lastViewedAt is greater than the last post

       2. lastViewedAt can be less than the first post in a channel if all the last viewed posts are deleted
          * return if oldest block exist and oldest post created_at is greater than the last viewed post
          i.e all posts are unread so the lastViewedAt is lessthan the first post

      The above two exceptions are added because we cannot select the chunk based on timestamp alone as these cases are out of bounds

      3. Normal cases where there are few unreads and few reads in a chunk as that is how unread API returns data
          * return getPostsChunkInChannelAroundTime
    */
    if (recentChunk) {
        // This would happen if there are no posts in channel.
        // If the system messages are deleted by sys admin.
        // Experimental changes like hiding Join/Leave still will have recent chunk so it follows the default path based on timestamp
        if (!recentChunk.order.length) {
            return recentChunk;
        }
        var order = recentChunk.order;
        var oldestPostInBlock = posts[order[order.length - 1]];
        // check for only oldest posts because this can be higher than the latest post if the last post is edited
        if (oldestPostInBlock.create_at <= timeStamp) {
            return recentChunk;
        }
    }
    var oldestPostsChunk = getOldestPostsChunkInChannel(state, channelId);
    if (oldestPostsChunk && oldestPostsChunk.order.length) {
        var order = oldestPostsChunk.order;
        var oldestPostInBlock = posts[order[order.length - 1]];
        if (oldestPostInBlock.create_at >= timeStamp) {
            return oldestPostsChunk;
        }
    }
    return getPostsChunkInChannelAroundTime(state, channelId, timeStamp);
}
exports.getUnreadPostsChunk = getUnreadPostsChunk;
exports.isPostIdSending = function (state, postId) {
    return state.entities.posts.pendingPostIds.some(function (sendingPostId) { return sendingPostId === postId; });
};
exports.makeIsPostCommentMention = function () {
    return reselect_1.createSelector(getAllPosts, getPostsInThread, common_1.getCurrentUser, getPost, function (allPosts, postsInThread, currentUser, post) {
        var e_4, _a;
        if (!post) {
            return false;
        }
        var threadRepliedToByCurrentUser = false;
        var isCommentMention = false;
        if (currentUser) {
            var rootId = post.root_id || post.id;
            var threadIds = postsInThread[rootId] || [];
            try {
                for (var threadIds_2 = tslib_1.__values(threadIds), threadIds_2_1 = threadIds_2.next(); !threadIds_2_1.done; threadIds_2_1 = threadIds_2.next()) {
                    var pid = threadIds_2_1.value;
                    var p = allPosts[pid];
                    if (!p) {
                        continue;
                    }
                    if (p.user_id === currentUser.id) {
                        threadRepliedToByCurrentUser = true;
                    }
                }
            }
            catch (e_4_1) { e_4 = { error: e_4_1 }; }
            finally {
                try {
                    if (threadIds_2_1 && !threadIds_2_1.done && (_a = threadIds_2.return)) _a.call(threadIds_2);
                }
                finally { if (e_4) throw e_4.error; }
            }
            var rootPost = allPosts[rootId];
            isCommentMention = post_utils_1.isPostCommentMention({ post: post, currentUser: currentUser, threadRepliedToByCurrentUser: threadRepliedToByCurrentUser, rootPost: rootPost });
        }
        return isCommentMention;
    });
};
function getExpandedLink(state, link) {
    return state.entities.posts.expandedURLs[link];
}
exports.getExpandedLink = getExpandedLink;
//# sourceMappingURL=posts.js.map

/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var constants_1 = __webpack_require__(6);
var general_1 = __webpack_require__(23);
var roles_1 = __webpack_require__(35);
var preference_utils_1 = __webpack_require__(32);
function isPostFlagged(postId, myPreferences) {
    var key = preference_utils_1.getPreferenceKey(constants_1.Preferences.CATEGORY_FLAGGED_POST, postId);
    return myPreferences.hasOwnProperty(key);
}
exports.isPostFlagged = isPostFlagged;
function isSystemMessage(post) {
    return Boolean(post.type && post.type.startsWith(constants_1.Posts.SYSTEM_MESSAGE_PREFIX));
}
exports.isSystemMessage = isSystemMessage;
function isMeMessage(post) {
    return Boolean(post.type && post.type === constants_1.Posts.POST_TYPES.ME);
}
exports.isMeMessage = isMeMessage;
function isFromWebhook(post) {
    return post.props && post.props.from_webhook;
}
exports.isFromWebhook = isFromWebhook;
function isPostEphemeral(post) {
    return post.type === constants_1.Posts.POST_TYPES.EPHEMERAL || post.type === constants_1.Posts.POST_TYPES.EPHEMERAL_ADD_TO_CHANNEL || post.state === constants_1.Posts.POST_DELETED;
}
exports.isPostEphemeral = isPostEphemeral;
function shouldIgnorePost(post) {
    return constants_1.Posts.IGNORE_POST_TYPES.includes(post.type);
}
exports.shouldIgnorePost = shouldIgnorePost;
function isUserActivityPost(postType) {
    return constants_1.Posts.USER_ACTIVITY_POST_TYPES.includes(postType);
}
exports.isUserActivityPost = isUserActivityPost;
function isPostOwner(userId, post) {
    return userId === post.user_id;
}
exports.isPostOwner = isPostOwner;
function isEdited(post) {
    return post.edit_at > 0;
}
exports.isEdited = isEdited;
function canDeletePost(state, config, license, teamId, channelId, userId, post, isAdmin, isSystemAdmin) {
    if (!post) {
        return false;
    }
    var isOwner = isPostOwner(userId, post);
    if (general_1.hasNewPermissions(state)) {
        var canDelete = roles_1.haveIChannelPermission(state, { team: teamId, channel: channelId, permission: constants_1.Permissions.DELETE_POST });
        if (!isOwner) {
            return canDelete && roles_1.haveIChannelPermission(state, { team: teamId, channel: channelId, permission: constants_1.Permissions.DELETE_OTHERS_POSTS });
        }
        return canDelete;
    }
    // Backwards compatibility with pre-advanced permissions config settings.
    if (license.IsLicensed === 'true') {
        return (config.RestrictPostDelete === constants_1.General.PERMISSIONS_ALL && (isOwner || isAdmin)) ||
            (config.RestrictPostDelete === constants_1.General.PERMISSIONS_TEAM_ADMIN && isAdmin) ||
            (config.RestrictPostDelete === constants_1.General.PERMISSIONS_SYSTEM_ADMIN && isSystemAdmin);
    }
    return isOwner || isAdmin;
}
exports.canDeletePost = canDeletePost;
function canEditPost(state, config, license, teamId, channelId, userId, post) {
    if (!post || isSystemMessage(post)) {
        return false;
    }
    var isOwner = isPostOwner(userId, post);
    var canEdit = true;
    if (general_1.hasNewPermissions(state)) {
        canEdit = canEdit && roles_1.haveIChannelPermission(state, { team: teamId, channel: channelId, permission: constants_1.Permissions.EDIT_POST });
        if (!isOwner) {
            canEdit = canEdit && roles_1.haveIChannelPermission(state, { team: teamId, channel: channelId, permission: constants_1.Permissions.EDIT_OTHERS_POSTS });
        }
        if (license.IsLicensed === 'true' && config.PostEditTimeLimit !== '-1' && config.PostEditTimeLimit !== -1) {
            var timeLeft = (post.create_at + (config.PostEditTimeLimit * 1000)) - Date.now();
            if (timeLeft <= 0) {
                canEdit = false;
            }
        }
    }
    else {
        // Backwards compatibility with pre-advanced permissions config settings.
        canEdit = isOwner && config.AllowEditPost !== 'never';
        if (config.AllowEditPost === constants_1.General.ALLOW_EDIT_POST_TIME_LIMIT) {
            var timeLeft = (post.create_at + (config.PostEditTimeLimit * 1000)) - Date.now();
            if (timeLeft <= 0) {
                canEdit = false;
            }
        }
    }
    return canEdit;
}
exports.canEditPost = canEditPost;
function getLastCreateAt(postsArray) {
    var createAt = postsArray.map(function (p) { return p.create_at; });
    if (createAt.length) {
        return Reflect.apply(Math.max, null, createAt);
    }
    return 0;
}
exports.getLastCreateAt = getLastCreateAt;
var joinLeavePostTypes = [
    constants_1.Posts.POST_TYPES.JOIN_LEAVE,
    constants_1.Posts.POST_TYPES.JOIN_CHANNEL,
    constants_1.Posts.POST_TYPES.LEAVE_CHANNEL,
    constants_1.Posts.POST_TYPES.ADD_REMOVE,
    constants_1.Posts.POST_TYPES.ADD_TO_CHANNEL,
    constants_1.Posts.POST_TYPES.REMOVE_FROM_CHANNEL,
    constants_1.Posts.POST_TYPES.JOIN_TEAM,
    constants_1.Posts.POST_TYPES.LEAVE_TEAM,
    constants_1.Posts.POST_TYPES.ADD_TO_TEAM,
    constants_1.Posts.POST_TYPES.REMOVE_FROM_TEAM,
    constants_1.Posts.POST_TYPES.COMBINED_USER_ACTIVITY,
];
// Returns true if a post should be hidden when the user has Show Join/Leave Messages disabled
function shouldFilterJoinLeavePost(post, showJoinLeave, currentUsername) {
    if (showJoinLeave) {
        return false;
    }
    // Don't filter out non-join/leave messages
    if (joinLeavePostTypes.indexOf(post.type) === -1) {
        return false;
    }
    // Don't filter out join/leave messages about the current user
    return !isJoinLeavePostForUsername(post, currentUsername);
}
exports.shouldFilterJoinLeavePost = shouldFilterJoinLeavePost;
function isJoinLeavePostForUsername(post, currentUsername) {
    var e_1, _a;
    if (!post.props || !currentUsername) {
        return false;
    }
    if (post.user_activity_posts) {
        try {
            for (var _b = tslib_1.__values(post.user_activity_posts), _c = _b.next(); !_c.done; _c = _b.next()) {
                var childPost = _c.value;
                if (isJoinLeavePostForUsername(childPost, currentUsername)) {
                    // If any of the contained posts are for this user, the client will
                    // need to figure out how to render the post
                    return true;
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_1) throw e_1.error; }
        }
    }
    return post.props.username === currentUsername ||
        post.props.addedUsername === currentUsername ||
        post.props.removedUsername === currentUsername;
}
function isPostPendingOrFailed(post) {
    return post.failed || post.id === post.pending_post_id;
}
exports.isPostPendingOrFailed = isPostPendingOrFailed;
function comparePosts(a, b) {
    var aIsPendingOrFailed = isPostPendingOrFailed(a);
    var bIsPendingOrFailed = isPostPendingOrFailed(b);
    if (aIsPendingOrFailed && !bIsPendingOrFailed) {
        return -1;
    }
    else if (!aIsPendingOrFailed && bIsPendingOrFailed) {
        return 1;
    }
    if (a.create_at > b.create_at) {
        return -1;
    }
    else if (a.create_at < b.create_at) {
        return 1;
    }
    return 0;
}
exports.comparePosts = comparePosts;
function isPostCommentMention(_a) {
    var post = _a.post, currentUser = _a.currentUser, threadRepliedToByCurrentUser = _a.threadRepliedToByCurrentUser, rootPost = _a.rootPost;
    var commentsNotifyLevel = constants_1.Preferences.COMMENTS_NEVER;
    var isCommentMention = false;
    var threadCreatedByCurrentUser = false;
    if (rootPost && rootPost.user_id === currentUser.id) {
        threadCreatedByCurrentUser = true;
    }
    if (currentUser.notify_props && currentUser.notify_props.comments) {
        commentsNotifyLevel = currentUser.notify_props.comments;
    }
    var notCurrentUser = post.user_id !== currentUser.id || (post.props && post.props.from_webhook);
    if (notCurrentUser) {
        if (commentsNotifyLevel === constants_1.Preferences.COMMENTS_ANY && (threadCreatedByCurrentUser || threadRepliedToByCurrentUser)) {
            isCommentMention = true;
        }
        else if (commentsNotifyLevel === constants_1.Preferences.COMMENTS_ROOT && threadCreatedByCurrentUser) {
            isCommentMention = true;
        }
    }
    return isCommentMention;
}
exports.isPostCommentMention = isPostCommentMention;
function fromAutoResponder(post) {
    return Boolean(post.type && (post.type === constants_1.Posts.SYSTEM_AUTO_RESPONDER));
}
exports.fromAutoResponder = fromAutoResponder;
//# sourceMappingURL=post_utils.js.map

/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect = tslib_1.__importStar(__webpack_require__(5));
var common_1 = __webpack_require__(22);
var teams_1 = __webpack_require__(27);
var roles_helpers_1 = __webpack_require__(28);
exports.getMySystemPermissions = roles_helpers_1.getMySystemPermissions;
exports.getMySystemRoles = roles_helpers_1.getMySystemRoles;
exports.getRoles = roles_helpers_1.getRoles;
exports.getMyTeamRoles = reselect.createSelector(teams_1.getTeamMemberships, function (teamsMemberships) {
    var roles = {};
    if (teamsMemberships) {
        for (var key in teamsMemberships) {
            if (teamsMemberships.hasOwnProperty(key) && teamsMemberships[key].roles) {
                roles[key] = new Set(teamsMemberships[key].roles.split(' '));
            }
        }
    }
    return roles;
});
exports.getMyChannelRoles = reselect.createSelector(function (state) { return state.entities.channels.myMembers; }, function (channelsMemberships) {
    var roles = {};
    if (channelsMemberships) {
        for (var key in channelsMemberships) {
            if (channelsMemberships.hasOwnProperty(key) && channelsMemberships[key].roles) {
                roles[key] = new Set(channelsMemberships[key].roles.split(' '));
            }
        }
    }
    return roles;
});
exports.getMyRoles = reselect.createSelector(roles_helpers_1.getMySystemRoles, exports.getMyTeamRoles, exports.getMyChannelRoles, function (systemRoles, teamRoles, channelRoles) {
    return {
        system: systemRoles,
        team: teamRoles,
        channel: channelRoles,
    };
});
exports.getRolesById = reselect.createSelector(roles_helpers_1.getRoles, function (rolesByName) {
    var e_1, _a;
    var rolesById = {};
    try {
        for (var _b = tslib_1.__values(Object.values(rolesByName)), _c = _b.next(); !_c.done; _c = _b.next()) {
            var role = _c.value;
            rolesById[role.id] = role;
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return rolesById;
});
exports.getMyCurrentTeamPermissions = reselect.createSelector(exports.getMyTeamRoles, roles_helpers_1.getRoles, roles_helpers_1.getMySystemPermissions, teams_1.getCurrentTeamId, function (myTeamRoles, roles, systemPermissions, teamId) {
    var e_2, _a, e_3, _b, e_4, _c;
    var permissions = new Set();
    if (myTeamRoles[teamId]) {
        try {
            for (var _d = tslib_1.__values(myTeamRoles[teamId]), _e = _d.next(); !_e.done; _e = _d.next()) {
                var roleName = _e.value;
                if (roles[roleName]) {
                    try {
                        for (var _f = (e_3 = void 0, tslib_1.__values(roles[roleName].permissions)), _g = _f.next(); !_g.done; _g = _f.next()) {
                            var permission = _g.value;
                            permissions.add(permission);
                        }
                    }
                    catch (e_3_1) { e_3 = { error: e_3_1 }; }
                    finally {
                        try {
                            if (_g && !_g.done && (_b = _f.return)) _b.call(_f);
                        }
                        finally { if (e_3) throw e_3.error; }
                    }
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
            }
            finally { if (e_2) throw e_2.error; }
        }
    }
    try {
        for (var systemPermissions_1 = tslib_1.__values(systemPermissions), systemPermissions_1_1 = systemPermissions_1.next(); !systemPermissions_1_1.done; systemPermissions_1_1 = systemPermissions_1.next()) {
            var permission = systemPermissions_1_1.value;
            permissions.add(permission);
        }
    }
    catch (e_4_1) { e_4 = { error: e_4_1 }; }
    finally {
        try {
            if (systemPermissions_1_1 && !systemPermissions_1_1.done && (_c = systemPermissions_1.return)) _c.call(systemPermissions_1);
        }
        finally { if (e_4) throw e_4.error; }
    }
    return permissions;
});
exports.getMyCurrentChannelPermissions = reselect.createSelector(exports.getMyChannelRoles, roles_helpers_1.getRoles, exports.getMyCurrentTeamPermissions, common_1.getCurrentChannelId, function (myChannelRoles, roles, teamPermissions, channelId) {
    var e_5, _a, e_6, _b, e_7, _c;
    var permissions = new Set();
    if (myChannelRoles[channelId]) {
        try {
            for (var _d = tslib_1.__values(myChannelRoles[channelId]), _e = _d.next(); !_e.done; _e = _d.next()) {
                var roleName = _e.value;
                if (roles[roleName]) {
                    try {
                        for (var _f = (e_6 = void 0, tslib_1.__values(roles[roleName].permissions)), _g = _f.next(); !_g.done; _g = _f.next()) {
                            var permission = _g.value;
                            permissions.add(permission);
                        }
                    }
                    catch (e_6_1) { e_6 = { error: e_6_1 }; }
                    finally {
                        try {
                            if (_g && !_g.done && (_b = _f.return)) _b.call(_f);
                        }
                        finally { if (e_6) throw e_6.error; }
                    }
                }
            }
        }
        catch (e_5_1) { e_5 = { error: e_5_1 }; }
        finally {
            try {
                if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
            }
            finally { if (e_5) throw e_5.error; }
        }
    }
    try {
        for (var teamPermissions_1 = tslib_1.__values(teamPermissions), teamPermissions_1_1 = teamPermissions_1.next(); !teamPermissions_1_1.done; teamPermissions_1_1 = teamPermissions_1.next()) {
            var permission = teamPermissions_1_1.value;
            permissions.add(permission);
        }
    }
    catch (e_7_1) { e_7 = { error: e_7_1 }; }
    finally {
        try {
            if (teamPermissions_1_1 && !teamPermissions_1_1.done && (_c = teamPermissions_1.return)) _c.call(teamPermissions_1);
        }
        finally { if (e_7) throw e_7.error; }
    }
    return permissions;
});
exports.getMyTeamPermissions = reselect.createSelector(exports.getMyTeamRoles, roles_helpers_1.getRoles, roles_helpers_1.getMySystemPermissions, function (state, options) { return options.team; }, function (myTeamRoles, roles, systemPermissions, teamId) {
    var e_8, _a, e_9, _b, e_10, _c;
    var permissions = new Set();
    if (myTeamRoles[teamId]) {
        try {
            for (var _d = tslib_1.__values(myTeamRoles[teamId]), _e = _d.next(); !_e.done; _e = _d.next()) {
                var roleName = _e.value;
                if (roles[roleName]) {
                    try {
                        for (var _f = (e_9 = void 0, tslib_1.__values(roles[roleName].permissions)), _g = _f.next(); !_g.done; _g = _f.next()) {
                            var permission = _g.value;
                            permissions.add(permission);
                        }
                    }
                    catch (e_9_1) { e_9 = { error: e_9_1 }; }
                    finally {
                        try {
                            if (_g && !_g.done && (_b = _f.return)) _b.call(_f);
                        }
                        finally { if (e_9) throw e_9.error; }
                    }
                }
            }
        }
        catch (e_8_1) { e_8 = { error: e_8_1 }; }
        finally {
            try {
                if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
            }
            finally { if (e_8) throw e_8.error; }
        }
    }
    try {
        for (var systemPermissions_2 = tslib_1.__values(systemPermissions), systemPermissions_2_1 = systemPermissions_2.next(); !systemPermissions_2_1.done; systemPermissions_2_1 = systemPermissions_2.next()) {
            var permission = systemPermissions_2_1.value;
            permissions.add(permission);
        }
    }
    catch (e_10_1) { e_10 = { error: e_10_1 }; }
    finally {
        try {
            if (systemPermissions_2_1 && !systemPermissions_2_1.done && (_c = systemPermissions_2.return)) _c.call(systemPermissions_2);
        }
        finally { if (e_10) throw e_10.error; }
    }
    return permissions;
});
exports.getMyChannelPermissions = reselect.createSelector(exports.getMyChannelRoles, roles_helpers_1.getRoles, exports.getMyTeamPermissions, function (state, options) { return options.channel; }, function (myChannelRoles, roles, teamPermissions, channelId) {
    var e_11, _a, e_12, _b, e_13, _c;
    var permissions = new Set();
    if (myChannelRoles[channelId]) {
        try {
            for (var _d = tslib_1.__values(myChannelRoles[channelId]), _e = _d.next(); !_e.done; _e = _d.next()) {
                var roleName = _e.value;
                if (roles[roleName]) {
                    try {
                        for (var _f = (e_12 = void 0, tslib_1.__values(roles[roleName].permissions)), _g = _f.next(); !_g.done; _g = _f.next()) {
                            var permission = _g.value;
                            permissions.add(permission);
                        }
                    }
                    catch (e_12_1) { e_12 = { error: e_12_1 }; }
                    finally {
                        try {
                            if (_g && !_g.done && (_b = _f.return)) _b.call(_f);
                        }
                        finally { if (e_12) throw e_12.error; }
                    }
                }
            }
        }
        catch (e_11_1) { e_11 = { error: e_11_1 }; }
        finally {
            try {
                if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
            }
            finally { if (e_11) throw e_11.error; }
        }
    }
    try {
        for (var teamPermissions_2 = tslib_1.__values(teamPermissions), teamPermissions_2_1 = teamPermissions_2.next(); !teamPermissions_2_1.done; teamPermissions_2_1 = teamPermissions_2.next()) {
            var permission = teamPermissions_2_1.value;
            permissions.add(permission);
        }
    }
    catch (e_13_1) { e_13 = { error: e_13_1 }; }
    finally {
        try {
            if (teamPermissions_2_1 && !teamPermissions_2_1.done && (_c = teamPermissions_2.return)) _c.call(teamPermissions_2);
        }
        finally { if (e_13) throw e_13.error; }
    }
    return permissions;
});
exports.haveISystemPermission = reselect.createSelector(roles_helpers_1.getMySystemPermissions, function (state, options) { return options.permission; }, function (permissions, permission) {
    return permissions.has(permission);
});
exports.haveITeamPermission = reselect.createSelector(exports.getMyTeamPermissions, function (state, options) { return options.permission; }, function (permissions, permission) {
    return permissions.has(permission);
});
exports.haveIChannelPermission = reselect.createSelector(exports.getMyChannelPermissions, function (state, options) { return options.permission; }, function (permissions, permission) {
    return permissions.has(permission);
});
exports.haveICurrentTeamPermission = reselect.createSelector(exports.getMyCurrentTeamPermissions, function (state, options) { return options.permission; }, function (permissions, permission) {
    return permissions.has(permission);
});
exports.haveICurrentChannelPermission = reselect.createSelector(exports.getMyCurrentChannelPermissions, function (state, options) { return options.permission; }, function (permissions, permission) {
    return permissions.has(permission);
});
//# sourceMappingURL=roles.js.map

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var reselect_1 = __webpack_require__(5);
var common_1 = __webpack_require__(22);
exports.getCurrentUser = common_1.getCurrentUser;
exports.getCurrentUserId = common_1.getCurrentUserId;
exports.getUsers = common_1.getUsers;
var general_1 = __webpack_require__(23);
var preferences_1 = __webpack_require__(26);
var user_utils_1 = __webpack_require__(29);
function getUserIdsInChannels(state) {
    return state.entities.users.profilesInChannel;
}
exports.getUserIdsInChannels = getUserIdsInChannels;
function getUserIdsNotInChannels(state) {
    return state.entities.users.profilesNotInChannel;
}
exports.getUserIdsNotInChannels = getUserIdsNotInChannels;
function getUserIdsInTeams(state) {
    return state.entities.users.profilesInTeam;
}
exports.getUserIdsInTeams = getUserIdsInTeams;
function getUserIdsNotInTeams(state) {
    return state.entities.users.profilesNotInTeam;
}
exports.getUserIdsNotInTeams = getUserIdsNotInTeams;
function getUserIdsWithoutTeam(state) {
    return state.entities.users.profilesWithoutTeam;
}
exports.getUserIdsWithoutTeam = getUserIdsWithoutTeam;
function getUserStatuses(state) {
    return state.entities.users.statuses;
}
exports.getUserStatuses = getUserStatuses;
function getUserSessions(state) {
    return state.entities.users.mySessions;
}
exports.getUserSessions = getUserSessions;
function getUserAudits(state) {
    return state.entities.users.myAudits;
}
exports.getUserAudits = getUserAudits;
function getUser(state, id) {
    return state.entities.users.profiles[id];
}
exports.getUser = getUser;
exports.getUsersByUsername = reselect_1.createSelector(common_1.getUsers, function (users) {
    var usersByUsername = {};
    for (var id in users) {
        if (users.hasOwnProperty(id)) {
            var user = users[id];
            usersByUsername[user.username] = user;
        }
    }
    return usersByUsername;
});
function getUserByUsername(state, username) {
    return exports.getUsersByUsername(state)[username];
}
exports.getUserByUsername = getUserByUsername;
exports.getUsersByEmail = reselect_1.createSelector(common_1.getUsers, function (users) {
    var e_1, _a;
    var usersByEmail = {};
    try {
        for (var _b = tslib_1.__values(Object.keys(users).map(function (key) { return users[key]; })), _c = _b.next(); !_c.done; _c = _b.next()) {
            var user = _c.value;
            usersByEmail[user.email] = user;
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return usersByEmail;
});
function getUserByEmail(state, email) {
    return exports.getUsersByEmail(state)[email];
}
exports.getUserByEmail = getUserByEmail;
exports.isCurrentUserSystemAdmin = reselect_1.createSelector(common_1.getCurrentUser, function (user) {
    var roles = user.roles || '';
    return user_utils_1.isSystemAdmin(roles);
});
exports.getCurrentUserRoles = reselect_1.createSelector(common_1.getMyCurrentChannelMembership, function (state) { return state.entities.teams.myMembers[state.entities.teams.currentTeamId]; }, common_1.getCurrentUser, function (currentChannelMembership, currentTeamMembership, currentUser) {
    var roles = '';
    if (currentTeamMembership) {
        roles += currentTeamMembership.roles + " ";
    }
    if (currentChannelMembership) {
        roles += currentChannelMembership.roles + " ";
    }
    if (currentUser) {
        roles += currentUser.roles;
    }
    return roles.trim();
});
exports.getCurrentUserMentionKeys = reselect_1.createSelector(common_1.getCurrentUser, function (user) {
    var keys = [];
    if (!user || !user.notify_props) {
        return keys;
    }
    if (user.notify_props.mention_keys) {
        keys = keys.concat(user.notify_props.mention_keys.split(',').map(function (key) {
            return { key: key };
        }));
    }
    if (user.notify_props.first_name === 'true' && user.first_name) {
        keys.push({ key: user.first_name, caseSensitive: true });
    }
    if (user.notify_props.channel === 'true') {
        keys.push({ key: '@channel' });
        keys.push({ key: '@all' });
        keys.push({ key: '@here' });
    }
    var usernameKey = '@' + user.username;
    if (keys.findIndex(function (key) { return key.key === usernameKey; }) === -1) {
        keys.push({ key: usernameKey });
    }
    return keys;
});
exports.getProfileSetInCurrentChannel = reselect_1.createSelector(common_1.getCurrentChannelId, getUserIdsInChannels, function (currentChannel, channelProfiles) {
    return channelProfiles[currentChannel];
});
exports.getProfileSetNotInCurrentChannel = reselect_1.createSelector(common_1.getCurrentChannelId, getUserIdsNotInChannels, function (currentChannel, channelProfiles) {
    return channelProfiles[currentChannel];
});
exports.getProfileSetInCurrentTeam = reselect_1.createSelector(function (state) { return state.entities.teams.currentTeamId; }, getUserIdsInTeams, function (currentTeam, teamProfiles) {
    return teamProfiles[currentTeam];
});
exports.getProfileSetNotInCurrentTeam = reselect_1.createSelector(function (state) { return state.entities.teams.currentTeamId; }, getUserIdsNotInTeams, function (currentTeam, teamProfiles) {
    return teamProfiles[currentTeam];
});
var PROFILE_SET_ALL = 'all';
function sortAndInjectProfiles(profiles, profileSet, skipInactive) {
    if (skipInactive === void 0) { skipInactive = false; }
    var currentProfiles = [];
    if (typeof profileSet === 'undefined') {
        return currentProfiles;
    }
    else if (profileSet === PROFILE_SET_ALL) {
        currentProfiles = Object.keys(profiles).map(function (key) { return profiles[key]; });
    }
    else {
        currentProfiles = Array.from(profileSet).map(function (p) { return profiles[p]; });
    }
    currentProfiles = currentProfiles.filter(function (profile) { return Boolean(profile); });
    if (skipInactive) {
        currentProfiles = currentProfiles.filter(function (profile) { return !(profile.delete_at && profile.delete_at !== 0); });
    }
    return currentProfiles.sort(user_utils_1.sortByUsername);
}
exports.getProfiles = reselect_1.createSelector(common_1.getUsers, function (state, filters) { return filters; }, function (profiles, filters) {
    return sortAndInjectProfiles(filterProfiles(profiles, filters), PROFILE_SET_ALL);
});
function filterProfiles(profiles, filters) {
    if (!filters) {
        return profiles;
    }
    var users = Object.keys(profiles).map(function (key) { return profiles[key]; });
    if (filters.role && filters.role !== '') {
        users = users.filter(function (user) { return user.roles && user.roles.includes((filters && filters.role) || ''); });
    }
    if (filters.inactive) {
        users = users.filter(function (user) { return user.delete_at !== 0; });
    }
    return users.reduce(function (acc, user) {
        acc[user.id] = user;
        return acc;
    }, {});
}
exports.getProfilesInCurrentChannel = reselect_1.createSelector(common_1.getUsers, exports.getProfileSetInCurrentChannel, function (profiles, currentChannelProfileSet) {
    return sortAndInjectProfiles(profiles, currentChannelProfileSet);
});
exports.getProfilesNotInCurrentChannel = reselect_1.createSelector(common_1.getUsers, exports.getProfileSetNotInCurrentChannel, function (profiles, notInCurrentChannelProfileSet) {
    return sortAndInjectProfiles(profiles, notInCurrentChannelProfileSet);
});
exports.getProfilesInCurrentTeam = reselect_1.createSelector(common_1.getUsers, exports.getProfileSetInCurrentTeam, function (profiles, currentTeamProfileSet) {
    return sortAndInjectProfiles(profiles, currentTeamProfileSet);
});
exports.getProfilesInTeam = reselect_1.createSelector(common_1.getUsers, getUserIdsInTeams, function (state, teamId) { return teamId; }, function (state, teamId, filters) { return filters; }, function (profiles, usersInTeams, teamId, filters) {
    return sortAndInjectProfiles(filterProfiles(profiles, filters), usersInTeams[teamId] || new Set());
});
exports.getProfilesNotInCurrentTeam = reselect_1.createSelector(common_1.getUsers, exports.getProfileSetNotInCurrentTeam, function (profiles, notInCurrentTeamProfileSet) {
    return sortAndInjectProfiles(profiles, notInCurrentTeamProfileSet);
});
exports.getProfilesWithoutTeam = reselect_1.createSelector(common_1.getUsers, getUserIdsWithoutTeam, function (state, filters) { return filters; }, function (profiles, withoutTeamProfileSet, filters) {
    return sortAndInjectProfiles(filterProfiles(profiles, filters), withoutTeamProfileSet);
});
function getStatusForUserId(state, userId) {
    return getUserStatuses(state)[userId];
}
exports.getStatusForUserId = getStatusForUserId;
function getTotalUsersStats(state) {
    return state.entities.users.stats;
}
exports.getTotalUsersStats = getTotalUsersStats;
function searchProfiles(state, term, skipCurrent, filters) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var users = common_1.getUsers(state);
    var profiles = user_utils_1.filterProfilesMatchingTerm(Object.keys(users).map(function (key) { return users[key]; }), term);
    var filteredProfilesMap = filterProfiles(user_utils_1.profileListToMap(profiles), filters);
    var filteredProfiles = Object.keys(filteredProfilesMap).map(function (key) { return filteredProfilesMap[key]; });
    if (skipCurrent) {
        removeCurrentUserFromList(filteredProfiles, common_1.getCurrentUserId(state));
    }
    return filteredProfiles;
}
exports.searchProfiles = searchProfiles;
function searchProfilesInCurrentChannel(state, term, skipCurrent) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var profiles = user_utils_1.filterProfilesMatchingTerm(exports.getProfilesInCurrentChannel(state), term);
    if (skipCurrent) {
        removeCurrentUserFromList(profiles, common_1.getCurrentUserId(state));
    }
    return profiles;
}
exports.searchProfilesInCurrentChannel = searchProfilesInCurrentChannel;
function searchProfilesNotInCurrentChannel(state, term, skipCurrent) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var profiles = user_utils_1.filterProfilesMatchingTerm(exports.getProfilesNotInCurrentChannel(state), term);
    if (skipCurrent) {
        removeCurrentUserFromList(profiles, common_1.getCurrentUserId(state));
    }
    return profiles;
}
exports.searchProfilesNotInCurrentChannel = searchProfilesNotInCurrentChannel;
function searchProfilesInCurrentTeam(state, term, skipCurrent) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var profiles = user_utils_1.filterProfilesMatchingTerm(exports.getProfilesInCurrentTeam(state), term);
    if (skipCurrent) {
        removeCurrentUserFromList(profiles, common_1.getCurrentUserId(state));
    }
    return profiles;
}
exports.searchProfilesInCurrentTeam = searchProfilesInCurrentTeam;
function searchProfilesInTeam(state, teamId, term, skipCurrent, filters) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var profiles = user_utils_1.filterProfilesMatchingTerm(exports.getProfilesInTeam(state, teamId), term);
    var filteredProfilesMap = filterProfiles(user_utils_1.profileListToMap(profiles), filters);
    var filteredProfiles = Object.keys(filteredProfilesMap).map(function (key) { return filteredProfilesMap[key]; });
    if (skipCurrent) {
        removeCurrentUserFromList(filteredProfiles, common_1.getCurrentUserId(state));
    }
    return filteredProfiles;
}
exports.searchProfilesInTeam = searchProfilesInTeam;
function searchProfilesNotInCurrentTeam(state, term, skipCurrent) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var profiles = user_utils_1.filterProfilesMatchingTerm(exports.getProfilesNotInCurrentTeam(state), term);
    if (skipCurrent) {
        removeCurrentUserFromList(profiles, common_1.getCurrentUserId(state));
    }
    return profiles;
}
exports.searchProfilesNotInCurrentTeam = searchProfilesNotInCurrentTeam;
function searchProfilesWithoutTeam(state, term, skipCurrent, filters) {
    if (skipCurrent === void 0) { skipCurrent = false; }
    var filteredProfiles = user_utils_1.filterProfilesMatchingTerm(exports.getProfilesWithoutTeam(state, filters), term);
    if (skipCurrent) {
        removeCurrentUserFromList(filteredProfiles, common_1.getCurrentUserId(state));
    }
    return filteredProfiles;
}
exports.searchProfilesWithoutTeam = searchProfilesWithoutTeam;
function removeCurrentUserFromList(profiles, currentUserId) {
    var index = profiles.findIndex(function (p) { return p.id === currentUserId; });
    if (index >= 0) {
        profiles.splice(index, 1);
    }
}
exports.shouldShowTermsOfService = reselect_1.createSelector(general_1.getConfig, common_1.getCurrentUser, general_1.getLicense, function (config, user, license) {
    // Defaults to false if the user is not logged in or the setting doesn't exist
    var acceptedTermsId = user ? user.terms_of_service_id : '';
    var acceptedAt = user ? user.terms_of_service_create_at : 0;
    var featureEnabled = license.IsLicensed === 'true' && config.EnableCustomTermsOfService === 'true';
    var reacceptanceTime = parseInt(config.CustomTermsOfServiceReAcceptancePeriod, 10) * 1000 * 60 * 60 * 24;
    var timeElapsed = new Date().getTime() - acceptedAt;
    return Boolean(user && featureEnabled && (config.CustomTermsOfServiceId !== acceptedTermsId || timeElapsed > reacceptanceTime));
});
exports.getUsersInVisibleDMs = reselect_1.createSelector(common_1.getUsers, preferences_1.getDirectShowPreferences, function (users, preferences) {
    var dmUsers = [];
    preferences.forEach(function (pref) {
        if (pref.value === 'true' && users[pref.name]) {
            dmUsers.push(users[pref.name]);
        }
    });
    return dmUsers;
});
function makeGetProfilesForReactions() {
    return reselect_1.createSelector(common_1.getUsers, function (state, reactions) { return reactions; }, function (users, reactions) {
        var profiles = [];
        reactions.forEach(function (r) {
            if (users[r.user_id]) {
                profiles.push(users[r.user_id]);
            }
        });
        return profiles;
    });
}
exports.makeGetProfilesForReactions = makeGetProfilesForReactions;
function makeGetProfilesInChannel() {
    return reselect_1.createSelector(common_1.getUsers, getUserIdsInChannels, function (state, channelId) { return channelId; }, function (state, channelId, skipInactive) { return skipInactive; }, function (users, userIds, channelId, skipInactive) {
        if (skipInactive === void 0) { skipInactive = false; }
        var userIdsInChannel = userIds[channelId];
        if (!userIdsInChannel) {
            return [];
        }
        return sortAndInjectProfiles(users, userIdsInChannel, skipInactive);
    });
}
exports.makeGetProfilesInChannel = makeGetProfilesInChannel;
function makeGetProfilesNotInChannel() {
    return reselect_1.createSelector(common_1.getUsers, getUserIdsNotInChannels, function (state, channelId) { return channelId; }, function (state, channelId, skipInactive) { return skipInactive; }, function (users, userIds, channelId, skipInactive) {
        if (skipInactive === void 0) { skipInactive = false; }
        var userIdsInChannel = userIds[channelId];
        if (!userIdsInChannel) {
            return [];
        }
        return sortAndInjectProfiles(users, userIdsInChannel, skipInactive);
    });
}
exports.makeGetProfilesNotInChannel = makeGetProfilesNotInChannel;
function makeGetProfilesByIdsAndUsernames() {
    return reselect_1.createSelector(common_1.getUsers, exports.getUsersByUsername, function (state, props) { return props.allUserIds; }, function (state, props) { return props.allUsernames; }, function (allProfilesById, allProfilesByUsername, allUserIds, allUsernames) {
        var userProfiles = [];
        if (allUserIds && allUserIds.length > 0) {
            var profilesById = allUserIds.
                filter(function (userId) { return allProfilesById[userId]; }).
                map(function (userId) { return allProfilesById[userId]; });
            if (profilesById && profilesById.length > 0) {
                userProfiles.push.apply(userProfiles, tslib_1.__spread(profilesById));
            }
        }
        if (allUsernames && allUsernames.length > 0) {
            var profilesByUsername = allUsernames.
                filter(function (username) { return allProfilesByUsername[username]; }).
                map(function (username) { return allProfilesByUsername[username]; });
            if (profilesByUsername && profilesByUsername.length > 0) {
                userProfiles.push.apply(userProfiles, tslib_1.__spread(profilesByUsername));
            }
        }
        return userProfiles;
    });
}
exports.makeGetProfilesByIdsAndUsernames = makeGetProfilesByIdsAndUsernames;
function makeGetDisplayName() {
    return reselect_1.createSelector(function (state, userId) { return getUser(state, userId); }, preferences_1.getTeammateNameDisplaySetting, function (state, _, useFallbackUsername) {
        if (useFallbackUsername === void 0) { useFallbackUsername = true; }
        return useFallbackUsername;
    }, general_1.getConfig, function (user, teammateNameDisplaySetting, useFallbackUsername, config) {
        var useAdminTemmateNameDisplaySetting = config.LockTeammateNameDisplay === 'true';
        var adminTeammateNameDisplaySetting = config.TeammateNameDisplay;
        return user_utils_1.displayUsername(user, teammateNameDisplaySetting, useFallbackUsername, useAdminTemmateNameDisplaySetting, adminTeammateNameDisplaySetting);
    });
}
exports.makeGetDisplayName = makeGetDisplayName;
//# sourceMappingURL=users.js.map

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var _a;
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(4);
// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.
var constants_1 = __webpack_require__(6);
var general_1 = __webpack_require__(23);
var roles_1 = __webpack_require__(35);
var preference_utils_1 = __webpack_require__(32);
var user_utils_1 = __webpack_require__(29);
var channelTypeOrder = (_a = {},
    _a[constants_1.General.OPEN_CHANNEL] = 0,
    _a[constants_1.General.PRIVATE_CHANNEL] = 1,
    _a[constants_1.General.DM_CHANNEL] = 2,
    _a[constants_1.General.GM_CHANNEL] = 2,
    _a);
/**
 * Returns list of sorted channels grouped by type. Favorites here is considered as separated type.
 *
 * Example: {
 *  publicChannels: [...],
 *  privateChannels: [...],
 *  directAndGroupChannels: [...],
 *  favoriteChannels: [...]
 * }
 */
function buildDisplayableChannelList(usersState, allChannels, myMembers, config, myPreferences, teammateNameDisplay, lastPosts) {
    var missingDirectChannels = createMissingDirectChannels(usersState.currentUserId, allChannels, myPreferences);
    var currentUserId = usersState.currentUserId, profiles = usersState.profiles;
    var locale = getUserLocale(currentUserId, profiles);
    var channels = buildChannels(usersState, allChannels, missingDirectChannels, teammateNameDisplay, locale);
    var favoriteChannels = buildFavoriteChannels(channels, myPreferences, locale);
    var notFavoriteChannels = buildNotFavoriteChannels(channels, myPreferences);
    var directAndGroupChannels = buildDirectAndGroupChannels(notFavoriteChannels, myMembers, config, myPreferences, currentUserId, profiles, lastPosts);
    return {
        favoriteChannels: favoriteChannels,
        publicChannels: notFavoriteChannels.filter(isOpenChannel),
        privateChannels: notFavoriteChannels.filter(isPrivateChannel),
        directAndGroupChannels: directAndGroupChannels,
    };
}
exports.buildDisplayableChannelList = buildDisplayableChannelList;
function buildDisplayableChannelListWithUnreadSection(usersState, myChannels, myMembers, config, myPreferences, teammateNameDisplay, lastPosts) {
    var currentUserId = usersState.currentUserId, profiles = usersState.profiles;
    var locale = getUserLocale(currentUserId, profiles);
    var missingDirectChannels = createMissingDirectChannels(currentUserId, myChannels, myPreferences);
    var channels = buildChannels(usersState, myChannels, missingDirectChannels, teammateNameDisplay, locale);
    var unreadChannels = tslib_1.__spread(buildChannelsWithMentions(channels, myMembers, locale), buildUnreadChannels(channels, myMembers, locale));
    var notUnreadChannels = channels.filter(function (channel) { return !isUnreadChannel(myMembers, channel); });
    var favoriteChannels = buildFavoriteChannels(notUnreadChannels, myPreferences, locale);
    var notFavoriteChannels = buildNotFavoriteChannels(notUnreadChannels, myPreferences);
    var directAndGroupChannels = buildDirectAndGroupChannels(notFavoriteChannels, myMembers, config, myPreferences, currentUserId, profiles, lastPosts);
    return {
        unreadChannels: unreadChannels,
        favoriteChannels: favoriteChannels,
        publicChannels: notFavoriteChannels.filter(isOpenChannel),
        privateChannels: notFavoriteChannels.filter(isPrivateChannel),
        directAndGroupChannels: directAndGroupChannels,
    };
}
exports.buildDisplayableChannelListWithUnreadSection = buildDisplayableChannelListWithUnreadSection;
function completeDirectChannelInfo(usersState, teammateNameDisplay, channel) {
    if (isDirectChannel(channel)) {
        var teammateId = getUserIdFromChannelName(usersState.currentUserId, channel.name);
        // return empty string instead of `someone` default string for display_name
        return tslib_1.__assign(tslib_1.__assign({}, channel), { display_name: user_utils_1.displayUsername(usersState.profiles[teammateId], teammateNameDisplay, false), teammate_id: teammateId, status: usersState.statuses[teammateId] || 'offline' });
    }
    else if (isGroupChannel(channel)) {
        return completeDirectGroupInfo(usersState, teammateNameDisplay, channel);
    }
    return channel;
}
exports.completeDirectChannelInfo = completeDirectChannelInfo;
function completeDirectChannelDisplayName(currentUserId, profiles, userIdsInChannel, teammateNameDisplay, channel) {
    if (isDirectChannel(channel)) {
        var dmChannelClone = tslib_1.__assign({}, channel);
        var teammateId = getUserIdFromChannelName(currentUserId, channel.name);
        return Object.assign(dmChannelClone, { display_name: user_utils_1.displayUsername(profiles[teammateId], teammateNameDisplay) });
    }
    else if (isGroupChannel(channel) && userIdsInChannel && userIdsInChannel.size > 0) {
        var displayName = getGroupDisplayNameFromUserIds(Array.from(userIdsInChannel), profiles, currentUserId, teammateNameDisplay);
        return tslib_1.__assign(tslib_1.__assign({}, channel), { display_name: displayName });
    }
    return channel;
}
exports.completeDirectChannelDisplayName = completeDirectChannelDisplayName;
function cleanUpUrlable(input) {
    var cleaned = input.trim().replace(/-/g, ' ').replace(/[^\w\s]/gi, '').toLowerCase().replace(/\s/g, '-');
    cleaned = cleaned.replace(/-{2,}/, '-');
    cleaned = cleaned.replace(/^-+/, '');
    cleaned = cleaned.replace(/-+$/, '');
    return cleaned;
}
exports.cleanUpUrlable = cleanUpUrlable;
function getChannelByName(channels, name) {
    var channelIds = Object.keys(channels);
    for (var i = 0; i < channelIds.length; i++) {
        var id = channelIds[i];
        if (channels[id].name === name) {
            return channels[id];
        }
    }
    return null;
}
exports.getChannelByName = getChannelByName;
function getDirectChannelName(id, otherId) {
    var handle;
    if (otherId > id) {
        handle = id + '__' + otherId;
    }
    else {
        handle = otherId + '__' + id;
    }
    return handle;
}
exports.getDirectChannelName = getDirectChannelName;
function getUserIdFromChannelName(userId, channelName) {
    var ids = channelName.split('__');
    var otherUserId = '';
    if (ids[0] === userId) {
        otherUserId = ids[1];
    }
    else {
        otherUserId = ids[0];
    }
    return otherUserId;
}
exports.getUserIdFromChannelName = getUserIdFromChannelName;
function isAutoClosed(config, myPreferences, channel, channelActivity, channelArchiveTime, currentChannelId) {
    if (currentChannelId === void 0) { currentChannelId = ''; }
    var cutoff = new Date().getTime() - 7 * 24 * 60 * 60 * 1000;
    var viewTimePref = myPreferences[constants_1.Preferences.CATEGORY_CHANNEL_APPROXIMATE_VIEW_TIME + "--" + channel.id];
    var viewTime = viewTimePref ? parseInt(viewTimePref.value, 10) : 0;
    if (viewTime > cutoff) {
        return false;
    }
    var openTimePref = myPreferences[constants_1.Preferences.CATEGORY_CHANNEL_OPEN_TIME + "--" + channel.id];
    var openTime = openTimePref ? parseInt(openTimePref.value, 10) : 0;
    // Only close archived channels when not being viewed
    if (channel.id !== currentChannelId && channelArchiveTime && channelArchiveTime > openTime) {
        return true;
    }
    if (config.CloseUnusedDirectMessages !== 'true' || isFavoriteChannel(myPreferences, channel.id)) {
        return false;
    }
    var autoClose = myPreferences[constants_1.Preferences.CATEGORY_SIDEBAR_SETTINGS + "--close_unused_direct_messages"];
    if (!autoClose || autoClose.value === 'after_seven_days') {
        if (channelActivity && channelActivity > cutoff) {
            return false;
        }
        if (openTime > cutoff) {
            return false;
        }
        var lastActivity = channel.last_post_at;
        return !lastActivity || lastActivity < cutoff;
    }
    return false;
}
exports.isAutoClosed = isAutoClosed;
function isDirectChannel(channel) {
    return channel.type === constants_1.General.DM_CHANNEL;
}
exports.isDirectChannel = isDirectChannel;
function isDirectChannelVisible(otherUserOrOtherUserId, config, myPreferences, channel, lastPost, isUnread, currentChannelId) {
    if (currentChannelId === void 0) { currentChannelId = ''; }
    var otherUser = typeof otherUserOrOtherUserId === 'object' ? otherUserOrOtherUserId : null;
    var otherUserId = typeof otherUserOrOtherUserId === 'object' ? otherUserOrOtherUserId.id : otherUserOrOtherUserId;
    var dm = myPreferences[constants_1.Preferences.CATEGORY_DIRECT_CHANNEL_SHOW + "--" + otherUserId];
    if (!dm || dm.value !== 'true') {
        return false;
    }
    return isUnread || !isAutoClosed(config, myPreferences, channel, lastPost ? lastPost.create_at : 0, otherUser ? otherUser.delete_at : 0, currentChannelId);
}
exports.isDirectChannelVisible = isDirectChannelVisible;
function isGroupChannel(channel) {
    return channel.type === constants_1.General.GM_CHANNEL;
}
exports.isGroupChannel = isGroupChannel;
function isGroupChannelVisible(config, myPreferences, channel, lastPost, isUnread) {
    var gm = myPreferences[constants_1.Preferences.CATEGORY_GROUP_CHANNEL_SHOW + "--" + channel.id];
    if (!gm || gm.value !== 'true') {
        return false;
    }
    return isUnread || !isAutoClosed(config, myPreferences, channel, lastPost ? lastPost.create_at : 0, 0);
}
exports.isGroupChannelVisible = isGroupChannelVisible;
function isGroupOrDirectChannelVisible(channel, memberships, config, myPreferences, currentUserId, users, lastPosts) {
    var lastPost = lastPosts[channel.id];
    if (isGroupChannel(channel) && isGroupChannelVisible(config, myPreferences, channel, lastPost, isUnreadChannel(memberships, channel))) {
        return true;
    }
    if (!isDirectChannel(channel)) {
        return false;
    }
    var otherUserId = getUserIdFromChannelName(currentUserId, channel.name);
    return isDirectChannelVisible(users[otherUserId] || otherUserId, config, myPreferences, channel, lastPost, isUnreadChannel(memberships, channel));
}
exports.isGroupOrDirectChannelVisible = isGroupOrDirectChannelVisible;
function showCreateOption(state, config, license, teamId, channelType, isAdmin, isSystemAdmin) {
    if (general_1.hasNewPermissions(state)) {
        if (channelType === constants_1.General.OPEN_CHANNEL) {
            return roles_1.haveITeamPermission(state, { team: teamId, permission: constants_1.Permissions.CREATE_PUBLIC_CHANNEL });
        }
        else if (channelType === constants_1.General.PRIVATE_CHANNEL) {
            return roles_1.haveITeamPermission(state, { team: teamId, permission: constants_1.Permissions.CREATE_PRIVATE_CHANNEL });
        }
        return true;
    }
    if (license.IsLicensed !== 'true') {
        return true;
    }
    // Backwards compatibility with pre-advanced permissions config settings.
    if (channelType === constants_1.General.OPEN_CHANNEL) {
        if (config.RestrictPublicChannelCreation === constants_1.General.SYSTEM_ADMIN_ROLE && !isSystemAdmin) {
            return false;
        }
        else if (config.RestrictPublicChannelCreation === constants_1.General.TEAM_ADMIN_ROLE && !isAdmin) {
            return false;
        }
    }
    else if (channelType === constants_1.General.PRIVATE_CHANNEL) {
        if (config.RestrictPrivateChannelCreation === constants_1.General.SYSTEM_ADMIN_ROLE && !isSystemAdmin) {
            return false;
        }
        else if (config.RestrictPrivateChannelCreation === constants_1.General.TEAM_ADMIN_ROLE && !isAdmin) {
            return false;
        }
    }
    return true;
}
exports.showCreateOption = showCreateOption;
function showManagementOptions(state, config, license, channel, isAdmin, isSystemAdmin, isChannelAdmin) {
    if (general_1.hasNewPermissions(state)) {
        if (channel.type === constants_1.General.OPEN_CHANNEL) {
            return roles_1.haveIChannelPermission(state, { channel: channel.id, team: channel.team_id, permission: constants_1.Permissions.MANAGE_PUBLIC_CHANNEL_PROPERTIES });
        }
        else if (channel.type === constants_1.General.PRIVATE_CHANNEL) {
            return roles_1.haveIChannelPermission(state, { channel: channel.id, team: channel.team_id, permission: constants_1.Permissions.MANAGE_PRIVATE_CHANNEL_PROPERTIES });
        }
        return true;
    }
    if (license.IsLicensed !== 'true') {
        return true;
    }
    // Backwards compatibility with pre-advanced permissions config settings.
    if (channel.type === constants_1.General.OPEN_CHANNEL) {
        if (config.RestrictPublicChannelManagement === constants_1.General.SYSTEM_ADMIN_ROLE && !isSystemAdmin) {
            return false;
        }
        if (config.RestrictPublicChannelManagement === constants_1.General.TEAM_ADMIN_ROLE && !isAdmin) {
            return false;
        }
        if (config.RestrictPublicChannelManagement === constants_1.General.CHANNEL_ADMIN_ROLE && !isChannelAdmin && !isAdmin) {
            return false;
        }
    }
    else if (channel.type === constants_1.General.PRIVATE_CHANNEL) {
        if (config.RestrictPrivateChannelManagement === constants_1.General.SYSTEM_ADMIN_ROLE && !isSystemAdmin) {
            return false;
        }
        if (config.RestrictPrivateChannelManagement === constants_1.General.TEAM_ADMIN_ROLE && !isAdmin) {
            return false;
        }
        if (config.RestrictPrivateChannelManagement === constants_1.General.CHANNEL_ADMIN_ROLE && !isChannelAdmin && !isAdmin) {
            return false;
        }
    }
    return true;
}
exports.showManagementOptions = showManagementOptions;
function showDeleteOption(state, config, license, channel, isAdmin, isSystemAdmin, isChannelAdmin) {
    if (general_1.hasNewPermissions(state)) {
        if (channel.type === constants_1.General.OPEN_CHANNEL) {
            return roles_1.haveIChannelPermission(state, { channel: channel.id, team: channel.team_id, permission: constants_1.Permissions.DELETE_PUBLIC_CHANNEL });
        }
        else if (channel.type === constants_1.General.PRIVATE_CHANNEL) {
            return roles_1.haveIChannelPermission(state, { channel: channel.id, team: channel.team_id, permission: constants_1.Permissions.DELETE_PRIVATE_CHANNEL });
        }
        return true;
    }
    if (license.IsLicensed !== 'true') {
        return true;
    }
    // Backwards compatibility with pre-advanced permissions config settings.
    if (channel.type === constants_1.General.OPEN_CHANNEL) {
        if (config.RestrictPublicChannelDeletion === constants_1.General.SYSTEM_ADMIN_ROLE && !isSystemAdmin) {
            return false;
        }
        if (config.RestrictPublicChannelDeletion === constants_1.General.TEAM_ADMIN_ROLE && !isAdmin) {
            return false;
        }
        if (config.RestrictPublicChannelDeletion === constants_1.General.CHANNEL_ADMIN_ROLE && !isChannelAdmin && !isAdmin) {
            return false;
        }
    }
    else if (channel.type === constants_1.General.PRIVATE_CHANNEL) {
        if (config.RestrictPrivateChannelDeletion === constants_1.General.SYSTEM_ADMIN_ROLE && !isSystemAdmin) {
            return false;
        }
        if (config.RestrictPrivateChannelDeletion === constants_1.General.TEAM_ADMIN_ROLE && !isAdmin) {
            return false;
        }
        if (config.RestrictPrivateChannelDeletion === constants_1.General.CHANNEL_ADMIN_ROLE && !isChannelAdmin && !isAdmin) {
            return false;
        }
    }
    return true;
}
exports.showDeleteOption = showDeleteOption;
// Backwards compatibility with pre-advanced permissions config settings.
function canManageMembersOldPermissions(channel, user, teamMember, channelMember, config, license) {
    if (channel.type === constants_1.General.DM_CHANNEL ||
        channel.type === constants_1.General.GM_CHANNEL ||
        channel.name === constants_1.General.DEFAULT_CHANNEL) {
        return false;
    }
    if (license.IsLicensed !== 'true') {
        return true;
    }
    if (channel.type === constants_1.General.PRIVATE_CHANNEL) {
        var isSystemAdmin = user.roles.includes(constants_1.General.SYSTEM_ADMIN_ROLE);
        if (config.RestrictPrivateChannelManageMembers === constants_1.General.PERMISSIONS_SYSTEM_ADMIN && !isSystemAdmin) {
            return false;
        }
        var isTeamAdmin = teamMember.roles.includes(constants_1.General.TEAM_ADMIN_ROLE);
        if (config.RestrictPrivateChannelManageMembers === constants_1.General.PERMISSIONS_TEAM_ADMIN && !isTeamAdmin && !isSystemAdmin) {
            return false;
        }
        var isChannelAdmin = channelMember.roles.includes(constants_1.General.CHANNEL_ADMIN_ROLE);
        if (config.RestrictPrivateChannelManageMembers === constants_1.General.PERMISSIONS_CHANNEL_ADMIN && !isChannelAdmin && !isTeamAdmin && !isSystemAdmin) {
            return false;
        }
    }
    return true;
}
exports.canManageMembersOldPermissions = canManageMembersOldPermissions;
function getChannelsIdForTeam(state, teamId) {
    var channels = state.entities.channels.channels;
    return Object.keys(channels).map(function (key) { return channels[key]; }).reduce(function (res, channel) {
        if (channel.team_id === teamId) {
            res.push(channel.id);
        }
        return res;
    }, []);
}
exports.getChannelsIdForTeam = getChannelsIdForTeam;
function getGroupDisplayNameFromUserIds(userIds, profiles, currentUserId, teammateNameDisplay) {
    var names = [];
    userIds.forEach(function (id) {
        if (id !== currentUserId) {
            names.push(user_utils_1.displayUsername(profiles[id], teammateNameDisplay));
        }
    });
    function sortUsernames(a, b) {
        var locale = getUserLocale(currentUserId, profiles);
        return a.localeCompare(b, locale, { numeric: true });
    }
    return names.sort(sortUsernames).join(', ');
}
exports.getGroupDisplayNameFromUserIds = getGroupDisplayNameFromUserIds;
function isFavoriteChannel(myPreferences, id) {
    var fav = myPreferences[constants_1.Preferences.CATEGORY_FAVORITE_CHANNEL + "--" + id];
    return fav ? fav.value === 'true' : false;
}
exports.isFavoriteChannel = isFavoriteChannel;
function isDefault(channel) {
    return channel.name === constants_1.General.DEFAULT_CHANNEL;
}
exports.isDefault = isDefault;
//====================================================
function createFakeChannel(userId, otherUserId) {
    return {
        name: getDirectChannelName(userId, otherUserId),
        create_at: 0,
        update_at: 0,
        delete_at: 0,
        extra_update_at: 0,
        last_post_at: 0,
        total_msg_count: 0,
        type: constants_1.General.DM_CHANNEL,
        fake: true,
        team_id: '',
        scheme_id: '',
        purpose: '',
        header: '',
        id: '',
        display_name: '',
        creator_id: '',
        group_constrained: false,
    };
}
function createFakeChannelCurried(userId) {
    return function (otherUserId) { return createFakeChannel(userId, otherUserId); };
}
function createMissingDirectChannels(currentUserId, allChannels, myPreferences) {
    var directChannelsDisplayPreferences = preference_utils_1.getPreferencesByCategory(myPreferences, constants_1.Preferences.CATEGORY_DIRECT_CHANNEL_SHOW);
    return Array.
        from(directChannelsDisplayPreferences).
        filter(function (entry) { return entry[1] === 'true'; }).
        map(function (entry) { return entry[0]; }).
        filter(function (teammateId) { return !allChannels.some(isDirectChannelForUser.bind(null, currentUserId, teammateId)); }).
        map(createFakeChannelCurried(currentUserId));
}
function completeDirectGroupInfo(usersState, teammateNameDisplay, channel) {
    var currentUserId = usersState.currentUserId, profiles = usersState.profiles, profilesInChannel = usersState.profilesInChannel;
    var profilesIds = profilesInChannel[channel.id];
    var gm = tslib_1.__assign({}, channel);
    if (profilesIds) {
        gm.display_name = getGroupDisplayNameFromUserIds(profilesIds, profiles, currentUserId, teammateNameDisplay);
        return gm;
    }
    var usernames = gm.display_name.split(', ');
    var users = Object.keys(profiles).map(function (key) { return profiles[key]; });
    var userIds = [];
    usernames.forEach(function (username) {
        var u = users.find(function (p) { return p.username === username; });
        if (u) {
            userIds.push(u.id);
        }
    });
    if (usernames.length === userIds.length) {
        gm.display_name = getGroupDisplayNameFromUserIds(userIds, profiles, currentUserId, teammateNameDisplay);
        return gm;
    }
    return channel;
}
function isDirectChannelForUser(userId, otherUserId, channel) {
    return channel.type === constants_1.General.DM_CHANNEL && getUserIdFromChannelName(userId, channel.name) === otherUserId;
}
function channelHasMentions(members, channel) {
    var member = members[channel.id];
    if (member) {
        return member.mention_count > 0;
    }
    return false;
}
function channelHasUnreadMessages(members, channel) {
    var member = members[channel.id];
    if (member) {
        var msgCount = channel.total_msg_count - member.msg_count;
        var onlyMentions = member.notify_props && member.notify_props.mark_unread === constants_1.General.MENTION;
        return (Boolean(msgCount) && !onlyMentions && member.mention_count === 0);
    }
    return false;
}
function isUnreadChannel(members, channel) {
    var member = members[channel.id];
    if (member) {
        var msgCount = channel.total_msg_count - member.msg_count;
        var onlyMentions = member.notify_props && member.notify_props.mark_unread === constants_1.General.MENTION;
        return (member.mention_count > 0 || (Boolean(msgCount) && !onlyMentions));
    }
    return false;
}
exports.isUnreadChannel = isUnreadChannel;
function isNotDeletedChannel(channel) {
    return channel.delete_at === 0;
}
function isOpenChannel(channel) {
    return channel.type === constants_1.General.OPEN_CHANNEL;
}
exports.isOpenChannel = isOpenChannel;
function isPrivateChannel(channel) {
    return channel.type === constants_1.General.PRIVATE_CHANNEL;
}
exports.isPrivateChannel = isPrivateChannel;
function sortChannelsByTypeAndDisplayName(locale, a, b) {
    if (channelTypeOrder[a.type] !== channelTypeOrder[b.type]) {
        if (channelTypeOrder[a.type] < channelTypeOrder[b.type]) {
            return -1;
        }
        return 1;
    }
    var aDisplayName = filterName(a.display_name);
    var bDisplayName = filterName(b.display_name);
    if (aDisplayName !== bDisplayName) {
        return aDisplayName.toLowerCase().localeCompare(bDisplayName.toLowerCase(), locale, { numeric: true });
    }
    return a.name.toLowerCase().localeCompare(b.name.toLowerCase(), locale, { numeric: true });
}
exports.sortChannelsByTypeAndDisplayName = sortChannelsByTypeAndDisplayName;
function filterName(name) {
    return name.replace(/[.,'"\/#!$%\^&\*;:{}=\-_`~()]/g, ''); // eslint-disable-line no-useless-escape
}
function sortChannelsByDisplayName(locale, a, b) {
    // if both channels have the display_name defined
    if (a.display_name && b.display_name && a.display_name !== b.display_name) {
        return a.display_name.toLowerCase().localeCompare(b.display_name.toLowerCase(), locale, { numeric: true });
    }
    return a.name.toLowerCase().localeCompare(b.name.toLowerCase(), locale, { numeric: true });
}
exports.sortChannelsByDisplayName = sortChannelsByDisplayName;
function sortChannelsByDisplayNameAndMuted(locale, members, a, b) {
    var aMember = members[a.id];
    var bMember = members[b.id];
    if (isChannelMuted(bMember) === isChannelMuted(aMember)) {
        return sortChannelsByDisplayName(locale, a, b);
    }
    if (!isChannelMuted(bMember) && isChannelMuted(aMember)) {
        return 1;
    }
    return -1;
}
exports.sortChannelsByDisplayNameAndMuted = sortChannelsByDisplayNameAndMuted;
function sortChannelsByRecency(lastPosts, a, b) {
    var aLastPostAt = a.last_post_at;
    if (lastPosts[a.id] && lastPosts[a.id].create_at > a.last_post_at) {
        aLastPostAt = lastPosts[a.id].create_at;
    }
    var bLastPostAt = b.last_post_at;
    if (lastPosts[b.id] && lastPosts[b.id].create_at > b.last_post_at) {
        bLastPostAt = lastPosts[b.id].create_at;
    }
    return bLastPostAt - aLastPostAt;
}
exports.sortChannelsByRecency = sortChannelsByRecency;
function isChannelMuted(member) {
    return member && member.notify_props ? (member.notify_props.mark_unread === 'mention') : false;
}
exports.isChannelMuted = isChannelMuted;
function areChannelMentionsIgnored(channelMemberNotifyProps, currentUserNotifyProps) {
    var ignoreChannelMentionsDefault = constants_1.Users.IGNORE_CHANNEL_MENTIONS_OFF;
    if (currentUserNotifyProps.channel && currentUserNotifyProps.channel === 'false') {
        ignoreChannelMentionsDefault = constants_1.Users.IGNORE_CHANNEL_MENTIONS_ON;
    }
    var ignoreChannelMentions = channelMemberNotifyProps && channelMemberNotifyProps.ignore_channel_mentions;
    if (!ignoreChannelMentions || ignoreChannelMentions === constants_1.Users.IGNORE_CHANNEL_MENTIONS_DEFAULT) {
        ignoreChannelMentions = ignoreChannelMentionsDefault;
    }
    return ignoreChannelMentions !== constants_1.Users.IGNORE_CHANNEL_MENTIONS_OFF;
}
exports.areChannelMentionsIgnored = areChannelMentionsIgnored;
function buildChannels(usersState, channels, missingDirectChannels, teammateNameDisplay, locale) {
    return channels.
        concat(missingDirectChannels).
        map(function (c) { return completeDirectChannelInfo(usersState, teammateNameDisplay, c); }).
        filter(isNotDeletedChannel).
        sort(sortChannelsByTypeAndDisplayName.bind(null, locale));
}
function buildFavoriteChannels(channels, myPreferences, locale) {
    return channels.filter(function (channel) { return isFavoriteChannel(myPreferences, channel.id); }).sort(sortChannelsByDisplayName.bind(null, locale));
}
function buildNotFavoriteChannels(channels, myPreferences) {
    return channels.filter(function (channel) { return !isFavoriteChannel(myPreferences, channel.id); });
}
function buildDirectAndGroupChannels(channels, memberships, config, myPreferences, currentUserId, users, lastPosts) {
    return channels.filter(function (channel) {
        return isGroupOrDirectChannelVisible(channel, memberships, config, myPreferences, currentUserId, users, lastPosts);
    });
}
function buildChannelsWithMentions(channels, members, locale) {
    return channels.filter(channelHasMentions.bind(null, members)).
        sort(sortChannelsByDisplayName.bind(null, locale));
}
function buildUnreadChannels(channels, members, locale) {
    return channels.filter(channelHasUnreadMessages.bind(null, members)).
        sort(sortChannelsByDisplayName.bind(null, locale));
}
function getUserLocale(userId, profiles) {
    var locale = constants_1.General.DEFAULT_LOCALE;
    if (profiles && profiles[userId] && profiles[userId].locale) {
        locale = profiles[userId].locale;
    }
    return locale;
}
function filterChannelsMatchingTerm(channels, term) {
    var lowercasedTerm = term.toLowerCase();
    return channels.filter(function (channel) {
        if (!channel) {
            return false;
        }
        var name = (channel.name || '').toLowerCase();
        var displayName = (channel.display_name || '').toLowerCase();
        return name.startsWith(lowercasedTerm) ||
            displayName.startsWith(lowercasedTerm);
    });
}
exports.filterChannelsMatchingTerm = filterChannelsMatchingTerm;
//# sourceMappingURL=channel_utils.js.map

/***/ })
/******/ ]);